# Illustrativ ytjämförelse, 2025–2050

Modellversion 1.2.0. Endast för att visa beräkningssättet. 30 och 42 m² BOA per person är scenarioindata, inte rekommenderade Malmövärden. Samma befolkningsbana, 2,11 personer/hushåll och BOA/BTA 0,8. Övriga indata är modellens standard.

| Mått | kt CO₂e |
|---|---:|
| Referens byggande och mark | 1 422,85 |
| Alternativ byggande och mark | 1 172,91 |
| Undvikna utsläpp | 249,95 |
| Negativt förändringsbidrag | −249,95 |
| Energi, skillnad separat | 24,14 |
| Skillnad i modellens hela total | 274,09 |

Utsläppstotalen är den faktiska alternativberäkningen. Undvikna utsläpp är jämförelseinformation och dras inte av igen. Ingen borttagning av CO₂ ur atmosfären har beräknats. Underlaget innehåller ofullständigt verifierade schabloner, så detta är inte ett verifierat utsläppsbokslut.
