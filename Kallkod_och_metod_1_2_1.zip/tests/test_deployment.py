"""Kontrollera driftsättning med enbart tre filer, utan app/ och data/."""
import importlib.util
import io
import json
from pathlib import Path
import shutil
import tempfile
import unittest
import zipfile

ROOT = Path(__file__).resolve().parents[1]


class TestTreFiler(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.folder = Path(self.tmp.name)
        for name in ("streamlit_app.py", "requirements.txt"):
            shutil.copy2(ROOT / name, self.folder / name)
        self.files = {
            str(p.relative_to(ROOT)): p.read_text(encoding="utf-8")
            for folder in ("app", "data")
            for p in sorted((ROOT / folder).iterdir()) if p.is_file()
        }
        self.write_bundle()
        spec = importlib.util.spec_from_file_location("isolated_climate", self.folder / "streamlit_app.py")
        self.app = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.app)

    def write_bundle(self, value=None):
        payload = value if value is not None else {"format": 1, "files": self.files}
        (self.folder / "klimatperspektiv_data.json").write_text(json.dumps(payload), encoding="utf-8")

    def test_tre_filer_utan_mappar(self):
        self.assertFalse((self.folder / "app").exists())
        self.assertFalse((self.folder / "data").exists())
        html = self.app.page_html()
        self.assertIn("KlimatperspektivApp", html)
        self.assertIn("const VERSION = '1.2.1'", html)
        self.assertNotIn("{{app/", html)
        self.assertNotIn("{{data/", html)

    def test_samma_sida_som_kallkoden(self):
        expected = self.app.page_html()
        (self.folder / "klimatperspektiv_data.json").unlink()
        for folder in ("app", "data"):
            shutil.copytree(ROOT / folder, self.folder / folder)
        self.assertEqual(expected, self.app.page_html())

    def test_nedladdning_innehaller_exakt_samma_underlag(self):
        with zipfile.ZipFile(io.BytesIO(self.app.data_zip())) as archive:
            self.assertEqual(set(archive.namelist()), set(self.app.DATAFILER))
            for name in archive.namelist():
                self.assertEqual(archive.read(name).decode("utf-8"), self.files[name])

    def test_gamla_kvarvarande_mappar_paverkar_inte(self):
        expected = self.app.page_html()
        (self.folder / "app").mkdir()
        (self.folder / "app/shell.html").write_text("gammal sida")
        self.assertEqual(expected, self.app.page_html())

    def test_ofullstandig_datafil(self):
        self.files.pop("app/shell.html")
        self.write_bundle()
        with self.assertRaisesRegex(ValueError, "ofullständig"):
            self.app.page_html()

    def test_saknad_granssnittskod(self):
        self.files.pop("app/circular.js")
        self.write_bundle()
        with self.assertRaisesRegex(ValueError, "app/circular.js"):
            self.app.page_html()

    def test_felaktigt_dataformat(self):
        self.write_bundle({"format": 2, "files": {}})
        with self.assertRaisesRegex(ValueError, "okänt format"):
            self.app.page_html()

    def test_saknad_datafil_ger_handlingsbar_forklaring(self):
        (self.folder / "klimatperspektiv_data.json").unlink()
        with self.assertRaisesRegex(FileNotFoundError, "samma GitHub-mapp"):
            self.app.page_html()


if __name__ == "__main__":
    unittest.main()
