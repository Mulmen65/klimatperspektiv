"""Tester för sidbygget och underlaget. Kör:  python -m unittest discover tests"""
from __future__ import annotations

import hashlib
import json
import re
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import streamlit_app  # noqa: E402


class TestSida(unittest.TestCase):
    def test_sidan_ar_komplett(self):
        html = streamlit_app.assemble()
        self.assertNotRegex(html, r"\{\{(?:app|data)/[^}]*\}\}")
        for tag in ("d-deso", "d-land", "d-grund", "d-kol", "d-utb", "d-meta"):
            m = re.search(r'<script id="' + tag + r'" type="application/json">(.*?)</script>', html, re.S)
            self.assertIsNotNone(m, tag)
            json.loads(m.group(1))
        self.assertIn("root.Klimatperspektiv = factory()", html)
        self.assertIn("KlimatperspektivApp", html)
        self.assertLess(len(html.encode()), 5 * 1024 * 1024)

    def test_underlaget_hanger_ihop(self):
        data = ROOT / "data"
        deso = json.loads((data / "deso_2025_malmo.geojson").read_text(encoding="utf-8"))
        grund = json.loads((data / "grund_deso.json").read_text(encoding="utf-8"))
        kol = json.loads((data / "kol_deso.json").read_text(encoding="utf-8"))
        utb = json.loads((data / "utbyggnad_op2023.json").read_text(encoding="utf-8"))
        ids = [f["properties"]["id"] for f in deso["features"]]
        self.assertEqual(len(ids), 209)
        self.assertEqual(set(ids), set(grund["deso"]))
        self.assertEqual(set(ids), set(kol["deso"]))
        self.assertEqual(sum(d["bef"] for d in grund["deso"].values()), 365644)
        self.assertEqual({str(a["id"]) for a in utb["omraden"]}, set(kol["omraden"]))
        for a in utb["omraden"]:
            self.assertTrue(all(d["deso"] in grund["deso"] for d in a["delar"]), a["namn"])

    def test_kontrollsummor(self):
        meta = json.loads((ROOT / "data/metadata.json").read_text(encoding="utf-8"))
        for namn, summa in meta["sha256"].items():
            self.assertEqual(hashlib.sha256((ROOT / "data" / namn).read_bytes()).hexdigest(), summa, namn)

    def test_underlag_zip(self):
        self.assertGreater(len(streamlit_app.data_zip()), 100_000)


if __name__ == "__main__":
    unittest.main()
