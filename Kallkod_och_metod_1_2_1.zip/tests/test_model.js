/* Beräkningstester för Klimatperspektiv. Kör:  node tests/test_model.js */
'use strict';
const fs = require('fs'), path = require('path'), assert = require('assert');
const ROT = path.resolve(__dirname, '..'), M = require(path.join(ROT, 'app/model.js'));
const j = f => JSON.parse(fs.readFileSync(path.join(ROT, 'data', f), 'utf8'));
const D = {deso: j('deso_2025_malmo.geojson'), grund: j('grund_deso.json'), kol: j('kol_deso.json'), utb: j('utbyggnad_op2023.json')};
const S = M.prepare(D), sum = a => Array.from(a).reduce((x, y) => x + y, 0), nara = (a, b, tol = 1e-6) => Math.abs(a - b) <= tol * Math.max(1, Math.abs(a), Math.abs(b));
let n = 0; const test = (namn, f) => { try { f(); n++; console.log('ok  ' + namn); } catch (e) { console.error('FEL ' + namn + '\n    ' + e.message); process.exitCode = 1; } };
const R = M.compute(S, {}), ar = M.stadPerAr(R), pr = M.perioder(R);

test('underlaget: 209 DeSO, 365 644 invånare, 36 utbyggnadsområden', () => { assert.equal(S.n, 209); assert.equal(S.bef0, 365644); assert.equal(S.areas.length, 36); });
test('nuläget 2024 stämmer med Road2Zero-OP och Vägvis', () => {
  assert(nara(ar[0].energi, D.grund.energi.t, 1e-3), 'energi ' + ar[0].energi);
  const A = D.grund.mobilitet.stad.A, vantat = A.fuel + A.el * 37 / 90 + A.fordon;   // laddelen räknas om från Vägvis 90 g till 37 g CO2e/kWh
  assert(nara(ar[0].mob, vantat, 1e-4), 'mobilitet ' + ar[0].mob + ' mot ' + vantat);
  for (const c of ['mark', 'bygg', 'omb', 'nymob', 'nydrift']) assert.equal(ar[0][c], 0);
});
test('folkmängden per DeSO summerar till den angivna folkmängden varje år', () => {
  R.years.forEach((y, yi) => assert(nara(sum(R.pop[yi]), M.folkmangd(R.P, S.bef0, y), 1e-9), 'år ' + y));
  assert(nara(sum(R.pop[26]), 434994, 1e-9));
});
test('summan av DeSO är lika med stadens flöden (byggande, mark)', () => {
  R.stad.forEach((s, yi) => { assert(nara(sum(R.comp.bygg[yi]), s.bygg)); assert(nara(sum(R.comp.anl[yi]), s.anl)); assert(nara(sum(R.comp.omb[yi]), s.omb)); assert(nara(sum(R.comp.mark[yi]), s.mark)); });
});
test('ytbalans: behov = nybyggt + omvandling + påbyggnad + renovering + minskat behov', () => {
  for (const P of [{}, M.CIRK_NIVA.mattlig, M.CIRK_NIVA.ambitios]) for (const p of M.perioder(M.compute(S, P)))
    assert(nara(p.behov, p.nybyggd + p.omv + p.pab + p.ren + p.suffBta, 1e-9), JSON.stringify(P));
});
test('räkneexempel: nybyggnad 2030 med standardvärden', () => {
  const s = R.stad.find(x => x.year === 2030), N = (395094 - 381846) / 5 * 0 + (381846 - 365644) / 6;   // 2030 hör till perioden 2025–2030
  assert(nara(s.N, N, 1e-9));
  const bost = N / 2.11, fbh = bost * 0.85 * 90, sm = bost * 0.15 * 130, lok = N * (0.46 * 25 + 2), ers = 0.0005 * S.btaBef;
  const t = (fbh * 235 + sm * 150 + lok * 250 + ers * (S.bostAndel * 235 + (1 - S.bostAndel) * 250) + ers * 7) / 1000;
  assert(nara(s.bygg, t, 1e-9), s.bygg + ' mot ' + t);
});
test('anläggning: grundläggning per m² nybyggd yta och gator per m² utvecklad mark, bara i utbyggnadsområden', () => {
  const s = R.stad.find(x => x.year === 2030), ix = M.indexAr(M.UTV.insteg, 2030), ny = s.nyFbh + s.nySm + s.nyLok + s.ers;
  assert(nara(s.anl, (ny * 26 + s.utvHa * 1e4 * 15) * ix / 1000, 1e-9), s.anl + '');
  assert(nara(sum(R.stad.map(x => x.utvHa)), R.areas.reduce((t, a) => t + a.f * a.ha, 0), 1e-9));
  const F = M.compute(S, {lokUtb: 0}); assert.equal(sum(F.stad.map(x => x.utvHa)), 0); assert(sum(F.stad.map(x => x.anl)) > 0);
  assert.equal(sum(M.compute(S, {grundKgBta: 0, anlKgMark: 0}).stad.map(x => x.anl)), 0);
});
test('klimattrappor: referens före 2030, gränsvärde från 2030, 90 % lägre 2040 i färdplanen', () => {
  const P = M.params({}), Pt = M.params({klimatBygg: 'trappa'});
  assert.equal(M.byggFaktor(P, 'fbh', 2029), 358); assert.equal(M.byggFaktor(P, 'fbh', 2030), 235); assert.equal(M.byggFaktor(P, 'smahus', 2045), 150);
  assert(nara(M.byggFaktor(Pt, 'fbh', 2040), 0.1 * 358 * 1.15)); assert(nara(M.byggFaktor(Pt, 'fbh', 2037), (235 + 0.1 * 358 * 1.15) / 2));
  assert.equal(M.byggFaktor(M.params({klimatBygg: 'referens'}), 'lokal', 2050), 383);
});
test('emissionsfaktorer över tid som i Road2Zero-OP', () => {
  const P = M.params({});
  assert(nara(M.faktorer(P, 2026).el, 0.037)); assert(nara(M.faktorer(P, 2030).el, 0.037 * Math.pow(1 - 0.0354, 4)));
  assert(nara(M.flottaIndex(P, 2030), Math.pow(1 - 0.0458, 4)));
  assert(nara(M.faktorer(M.params({beccs: 'ja'}), 2030).fv, 0.056 * Math.pow(1 - 0.0163, 4) * 0.57));
  assert.equal(M.params({elVal: 'iea'}).efEl, 0.026); assert.equal(M.params({elVal: 'iea'}).elR1, -6.68);
});
test('markposten: full utbyggnad med tät blandad stad ger kolkartans 129,5 kt', () => {
  const L = M.compute(S, {andelFbh: 100}).areas.reduce((s, a) => s + a.L, 0) / 1000;
  assert(Math.abs(L - 129.5) < 0.05, 'fick ' + L.toFixed(2));
});
test('markposten följer utbyggnaden: aldrig mer än vid full utbyggnad, och noll utan utbyggnadsområden', () => {
  for (const a of R.areas) assert(a.mark <= a.L + 1e-9 && a.f <= 1 + 1e-12);
  assert(nara(sum(pr.map(p => p.mark)), R.areas.reduce((s, a) => s + a.mark, 0)));
  assert.equal(sum(M.perioder(M.compute(S, {lokUtb: 0})).map(p => p.mark)), 0);
  assert(sum(M.perioder(M.compute(S, {lokUtb: 0, fortMarkAndel: 20})).map(p => p.mark)) > 0);
});
test('utbyggnadsområdenas kapacitet hålls, och överskottet blir förtätning', () => {
  const X = M.compute(S, {pop2030: 450000, pop2035: 550000, pop2040: 650000, pop2045: 700000, pop2050: 750000, lokUtb: 100});
  for (const a of X.areas) assert(a.dw <= a.bostader + 1e-6, a.namn);
  assert(nara(X.areas.reduce((s, a) => s + a.dw, 0), 38850, 1e-9)); assert(sum(X.stad.map(s => s.fullt)) > 0);
  assert(nara(sum(X.pop[26]), 750000, 1e-9));
});
test('ordningen mellan områden: Fokus 1 byggs före Fokus 2, och klimatordningen ger lägre påverkan per bostad', () => {
  const F = M.compute(S, {omrOrdning: 'fokus'}), f1 = F.areas.filter(a => a.fokus === 1 && a.bostader > 0), f2 = F.areas.filter(a => a.fokus === 2 && a.bostader > 0);
  assert(f1.every(a => nara(a.dw, a.bostader, 1e-9)) || f2.every(a => a.dw === 0));
  const K = M.compute(S, {omrOrdning: 'klimat', perspektiv: 'B'}), Pp = M.compute(S, {perspektiv: 'B'}), tot = X => sum(M.stadPerAr(X).map(r => r.mark + r.nymob));
  assert(tot(K) < tot(Pp), tot(K) + ' mot ' + tot(Pp));
});
test('cirkulära åtgärder sänker byggandets klimatpåverkan, var för sig och tillsammans', () => {
  const bas = sum(pr.map(p => p.byggande + p.mark));
  for (const k of M.CIRK) { const x = sum(M.perioder(M.compute(S, {[k]: 20})).map(p => p.byggande + p.mark)); assert(x < bas, k + ': ' + x + ' mot ' + bas); }
  const m = sum(M.perioder(M.compute(S, M.CIRK_NIVA.mattlig)).map(p => p.byggande)), a = sum(M.perioder(M.compute(S, M.CIRK_NIVA.ambitios)).map(p => p.byggande));
  assert(a < m && m < sum(pr.map(p => p.byggande)));
});
test('referensen är oberoende av de cirkulära valen, och undvikna utsläpp är noll utan åtgärder', () => {
  const P = M.params(M.CIRK_NIVA.ambitios), Rr = M.compute(S, M.utanCirk(P));
  assert(nara(sum(M.perioder(Rr).map(p => p.byggande)), sum(pr.map(p => p.byggande)), 1e-12));
  assert(!M.harCirk(M.params({}))); assert(M.harCirk(P));
  const v = M.view(S, R, 'ack'); assert(Math.abs(sum(M.undvikt(v, v))) < 1e-6);
  const u = sum(M.undvikt(M.view(S, M.compute(S, P), 'ack'), M.view(S, Rr, 'ack'))); assert(u > 0);
});
test('taken för omvandling och påbyggnad hålls', () => {
  const X = M.compute(S, {omvAndel: 60, pabAndel: 40, omvTak: 2, pabTak: 1});
  assert(X.tak.cumOmv <= 0.02 * S.btaLokalTot + 1e-6); assert(X.tak.cumPab <= 0.01 * S.btaFbhTot + 1e-6); assert(X.stad.some(s => s.takOmv) && X.stad.some(s => s.takPab));
});
test('sufficiency: invånare i befintligt bestånd kräver ingen yta men räknas i folkmängd och mobilitet', () => {
  const X = M.compute(S, {suffBefintligt: 100, rivTakt: 0, perspektiv: 'B'}), p = M.perioder(X);
  assert.equal(sum(p.map(q => q.nybyggd - q.nyLok)), 0); assert(nara(sum(X.pop[26]), 434994, 1e-9)); assert(sum(X.comp.nymob[26]) > 0);
});
test('mobilitet A och B: nya invånare räknas i värd-DeSO (B) och över vägnätet (A)', () => {
  const B = M.compute(S, {perspektiv: 'B'}), yi = 26;
  let v = 0; for (let i = 0; i < S.n; i++) v += B.nyaInv[yi][i] / 2.11 * S.cph[i] * S.km[i];
  assert(nara(B.stad[yi].nyVkm, v, 1e-9));
  assert(nara(sum(R.comp.nymob[yi]), sum(R.comp.mob[yi]) * 0.5 * R.stad[yi].nyVkm / S.cityAvkm, 1e-9));
});
test('minskande folkmängd: inget byggs för befolkningen, och folkmängden följer indata', () => {
  const X = M.compute(S, {pop2030: 360000, pop2035: 355000, pop2040: 350000, pop2045: 345000, pop2050: 340000, rivTakt: 0});
  assert.equal(sum(M.perioder(X).map(p => p.nybyggd)), 0); assert(nara(sum(X.pop[26]), 340000, 1e-9));
});
test('funktionella enheter och statiska nyckeltal', () => {
  const v = M.view(S, R, 2050), r = v.rows[0];
  assert(nara(M.metric(r, 'total', 't_ha'), r.total / r.land_ha)); assert(nara(M.metric(r, 'total', 'kg_ha'), 1000 * r.total / r.land_ha)); assert(nara(M.metric(r, 'total', 't_inv'), r.total / r.bef));
  assert.equal(M.metric(r, 'kol_ha', 't_inv'), r.kol_ha);
  assert(nara(v.city.total, M.KOMP.reduce((s, c) => s + v.city[c], 0))); assert(nara(v.city.total, ar[26].total));
  const ack = M.view(S, R, 'ack'); assert.equal(ack.years, 26); assert(nara(ack.city.bygg, sum(pr.map(p => p.bygg))));
  assert(nara(v.city.kol_forrad, (sum(S.markkolC) + sum(S.bioC)) * 44 / 12));
});
test('lokalisering per ny bostad: bilresor, byggande och mark, högst i ytterområden med högt bilinnehav', () => {
  const v = M.view(S, R, 2050); for (const r of v.rows) assert(nara(r.per_bostad, r.pb.trafik + r.pb.bygg + r.pb.mark));
  const hog = v.rows.slice().sort((a, b) => b.per_bostad - a.per_bostad)[0], lag = v.rows.slice().sort((a, b) => a.per_bostad - b.per_bostad)[0];
  assert(hog.bil_hh > 2 * lag.bil_hh, hog.namn + ' ' + hog.bil_hh + ' mot ' + lag.namn + ' ' + lag.bil_hh);
});
test('parametrar: gränser, decimalkomma och okända värden', () => {
  assert.equal(M.params({andelFbh: 150}).andelFbh, 100); assert.equal(M.params({personerPerBostad: '2,5'}).personerPerBostad, 2.5);
  assert.equal(M.params({pop2050: '450 000'}).pop2050, 450000); assert.equal(M.params({klimatBygg: 'x'}).klimatBygg, 'gransvarde2030'); assert.equal(M.params({ar: 2031}).ar, 2050);
  assert.deepEqual(M.POP_NIVA.lag[2050], Math.round(365644 + 0.5 * (434994 - 365644)));
});
console.log(n + ' tester godkända');
