/* Grunddata per DeSO ur Road2Zero-OP (Mulmen65/road2zero, mappen op/): energi i befintliga byggnader, byggnadsbeståndets
   yta per byggnadstyp, mobilitet enligt Vägvis (modell A och B) samt hushåll, invånare och bilar.

   Skriptet kör Road2Zero-OP:s beräkningsmotor (op/app/model.js) med standardantaganden och sparar resultatet per DeSO i
   data/grund_deso.json. Klimatperspektiv räknar sedan vidare med egna emissionsfaktorer och scenarier.

   Kör:  node tools/bygg_grund.js <sökväg till road2zero/op> */
'use strict';
const fs = require('fs'), path = require('path');
const OP = process.argv[2];
if (!OP) { console.error('Ange sökvägen till road2zero/op'); process.exit(1); }
const ROT = path.resolve(__dirname, '..');
const M = require(path.join(OP, 'app/model.js'));
const pd = path.join(OP, 'projekt/malmo_op/data');
const las = f => JSON.parse(fs.readFileSync(path.join(pd, f), 'utf8'));
const D = {deso: las('kalla/deso_2025_malmo.geojson'), energi: las('energi_deklarationer.json'), mob: las('mobilitet_vagvis.json'), expl: las('exploatering_op2023.json')};
const S = M.prepare(D), P = M.params({}), eb = M.energyBase(S, P), it = M.energyItems(S, P), E = D.energi.kolumner;
const r = (x, d = 1) => Number(x.toFixed(d));

/* Atemp per DeSO och byggnadstyp, kalibrerad som i energyBase (kG per kalibreringsgrupp). */
const KL = S.KL, n = S.n;
const atemp = KL.map(() => new Float64Array(n));
for (let i = 0; i < it.m; i++) {
  const a = it.a[i] * eb.kG[it.grp[i]];
  if (it.stock[i]) { atemp[it.kl[i]][it.deso[i]] += a; continue; }
  for (const [d, w] of E.alloc[i]) atemp[it.kl[i]][d] += a * w;
}

(async () => {
  const U = await M.simulateEnergy(S, P);
  const mobDel = x => x && x.total > 0 ? {fuel: r((x.ttw || 0) + (x.wtt || 0) - (x.el || 0), 2), el: r(x.el || 0, 3), fordon: r(x.fordon || 0, 2), vkm: Math.round(x.vkm || 0),
    lo: r(x.p025 / x.total, 3), hi: r(x.p975 / x.total, 3)} : {fuel: 0, el: 0, fordon: 0, vkm: 0, lo: 1, hi: 1};
  const deso = {};
  S.ids.forEach((id, i) => {
    const p = D.deso.features[i].properties, h = D.mob.hushall[id] || {hh: 0, bef: 0, bil: 0}, b = D.mob.B_local[id] || {};
    deso[id] = {
      namn: p.regsoName || p.name, regso: p.regso, land_ha: p.land_ha, hh: h.hh, bef: h.bef, bil: h.bil,
      energi: {kwh_el: Math.round(eb.tEl[i] / P.efEl * 1000), kwh_fv: Math.round(eb.tFv[i] / P.efFv * 1000), atemp: Math.round(eb.atemp[i]),
        lo: eb.t[i] > 0 ? r(U.deso.p025[i] / eb.t[i], 3) : 1, hi: eb.t[i] > 0 ? r(U.deso.p975[i] / eb.t[i], 3) : 1},
      atemp: Object.fromEntries(KL.map((k, q) => [k, Math.round(atemp[q][i])])),
      A: mobDel(D.mob.A[id]), B: {...mobDel(b), cars: b.cars || 0}
    };
  });
  const st = D.mob.stad, tot = eb.t.reduce((a, b) => a + b, 0);
  const ut = {
    schema: 'klimatperspektiv-grund-1',
    kalla: 'Road2Zero-OP ' + M.VERSION + ' (Mulmen65/road2zero, op/), standardantaganden; mobilitet: ' + D.mob.kalla,
    basar: M.BASE_YEAR,
    energi: {ef_el: P.efEl, ef_fv: P.efFv, atemp_per_bta: P.atempFaktor, kalibrering: eb.kalibrering, t: r(tot, 0),
      intervall: {lo: r(U.city.p025 / tot, 3), hi: r(U.city.p975 / tot, 3), iterationer: P.iterationer},
      ej_kartlagda_t: r(eb.unmappedT, 1), deklarationer: D.energi.urval.beraknade_deklarationer, kartlagda: D.energi.urval.kartlagda,
      skattade_byggnader: D.energi.bestand.bta.length},
    mobilitet: {el_g_per_kwh: D.mob.elFaktor, stad: {A: {...mobDel(st.A), total: r(st.A.total, 0)}, B: {...mobDel(st.B_local), total: r(st.B_local.total, 0), cars: st.B_local.cars, hushall: st.B_local.hushall, bef: st.B_local.bef}}},
    deso
  };
  
  fs.writeFileSync(path.join(ROT, 'data/grund_deso.json'), JSON.stringify(ut));
  const sum = k => Object.values(deso).reduce((s, d) => s + k(d), 0);
  console.log('klart:', Object.keys(deso).length, 'DeSO; energi', Math.round(tot), 't (95 %', Math.round(U.city.p025), '–', Math.round(U.city.p975) + '); Atemp',
    Math.round(sum(d => d.energi.atemp) / 1e6 * 10) / 10, 'Mm²; mobilitet A', Math.round(st.A.total), 't, B', Math.round(st.B_local.total), 't; invånare', sum(d => d.bef));
  console.log('Atemp per typ (Mm²):', KL.map((k, q) => k + ' ' + (atemp[q].reduce((a, b) => a + b, 0) / 1e6).toFixed(2)).join(', '));
})();
