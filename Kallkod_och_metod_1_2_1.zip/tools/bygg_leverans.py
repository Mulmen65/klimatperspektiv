"""Bygg tre-filsleverans: python tools/bygg_leverans.py UTKATALOG."""
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
target = Path(sys.argv[1]).resolve()
target.mkdir(parents=True, exist_ok=True)
files = {
    str(p.relative_to(ROOT)): p.read_text(encoding="utf-8")
    for folder in ("app", "data")
    for p in sorted((ROOT / folder).iterdir()) if p.is_file()
}
payload = {"format": 1, "version": "1.2.1", "files": files}
(target / "klimatperspektiv_data.json").write_text(
    json.dumps(payload, ensure_ascii=False, separators=(",", ":")), encoding="utf-8"
)
for name in ("streamlit_app.py", "requirements.txt"):
    shutil.copy2(ROOT / name, target / name)
spec = importlib.util.spec_from_file_location("climate_build", target / "streamlit_app.py")
app = importlib.util.module_from_spec(spec)
spec.loader.exec_module(app)
(target / "Klimatperspektiv_Malmo_1_2_1.html").write_text(app.page_html(), encoding="utf-8")
shutil.copy2(ROOT / "KOM_IGANG.md", target / "LAS_MIG_FORST.md")
with zipfile.ZipFile(target / "Kallkod_och_metod_1_2_1.zip", "w", zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(ROOT.rglob("*")):
        if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc":
            archive.write(path, path.relative_to(ROOT))
print(target)
