"""Kolförråd per DeSO och per utbyggnadsområde ur SLU:s kolkartor och biomassalagret (samma källor och regler som
Mulmen65/road2zero-kolkarta, verktyg/bygg_kolkarta.py).

Läser bara Malmöutsnittet ur tre Cloud Optimized GeoTIFF (10 m, SWEREF 99 TM) över HTTP och skriver data/kol_deso.json:
  deso[id]     land_ha, ohardgjord_ha, markkol_hist [[t C/ha, antal 10 m-rutor], ...] (SOC + DOM, klasser om 5 t C/ha),
               markkol_tC, biomassa_tC (på ohårdgjord mark, inte på OSM-hårdgjort utan vegetation)
  omraden[id]  samma som road2zero-kolkarta/data/omraden.geojson (klasser om 1 t C/ha)

Kör:  python -I tools/bygg_kol.py <mapp med road2zero-kolkarta/data/kalla>      (kräver rasterio, shapely, numpy)
"""
import json
import os
import sys

import numpy as np
import rasterio
from rasterio.features import geometry_mask, rasterize
from rasterio.warp import reproject, Resampling, transform_geom
from rasterio.windows import from_bounds
from shapely.geometry import LineString, MultiPolygon, Polygon, mapping, shape
from shapely.ops import unary_union
from shapely.validation import make_valid

ROT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
URL = "/vsicurl/https://carbonaracarbon.blob.core.windows.net/carbon/{}.tif"
BBOX = (360000, 6148000, 392000, 6172000)   # SWEREF 99 TM, täcker Malmö kommun
MIN_LANDDEL_M2 = 5000
os.environ.setdefault("GDAL_DISABLE_READDIR_ON_OPEN", "EMPTY_DIR")

VEG = {('landuse', 'forest'), ('natural', 'wood'), ('natural', 'scrub'), ('natural', 'shrubbery'), ('leisure', 'park'), ('landuse', 'grass'),
       ('landuse', 'meadow'), ('natural', 'tree_row'), ('landuse', 'allotments'), ('surface', 'grass'), ('landuse', 'flowerbed'),
       ('leisure', 'dog_park'), ('natural', 'grassland'), ('natural', 'heath'), ('landuse', 'cemetery'), ('leisure', 'garden')}
SEAL = {('amenity', 'parking'), ('amenity', 'parking_space'), ('surface', 'asphalt'), ('surface', 'concrete'), ('surface', 'paving_stones'),
        ('leisure', 'swimming_pool'), ('surface', 'tartan'), ('surface', 'artificial_turf'), ('landuse', 'construction'), ('highway', 'pedestrian'),
        ('landuse', 'industrial'), ('landuse', 'retail'), ('landuse', 'commercial'), ('landuse', 'railway')}


def las(namn):
    with rasterio.open(URL.format(namn)) as s:
        w = from_bounds(*BBOX, transform=s.transform).round_offsets().round_lengths()
        return s.read(1, window=w, boundless=True, fill_value=s.nodata).astype(float), s.window_transform(w)


def osm_geom(f):
    g = f['g']
    try:
        if isinstance(g[0][0], (int, float)):
            s = Polygon(g) if (g[0] == g[-1] and len(g) >= 4) else LineString(g).buffer(0.00006)
        else:
            s = Polygon(g[0], g[1:])
        return transform_geom('EPSG:4326', 'EPSG:3006', mapping(s.buffer(0)))
    except Exception:
        return None


def hist(v, steg):
    varden, antal = np.unique((np.round(v / steg) * steg).astype(int), return_counts=True)
    return [[int(a), int(b)] for a, b in zip(varden, antal)]


def main(kalla):
    soc, tr = las('soc')
    dom, _ = las('dom')
    bio, trb = las('biomass')
    if bio.shape != soc.shape or trb != tr:
        b2 = np.full(soc.shape, np.nan)
        reproject(bio, b2, src_transform=trb, src_crs='EPSG:3006', dst_transform=tr, dst_crs='EPSG:3006', resampling=Resampling.nearest)
        bio = b2
    bio[(bio < 0) | np.isnan(bio)] = 0
    oforseglad = soc > 0
    markkol = np.where(oforseglad, (soc + np.where(dom > 0, dom, 0)) / 1000, np.nan)   # t C/ha

    osm = json.load(open(os.path.join(kalla, 'osm_markanvandning_utbyggnad.json')))['features']
    gs = [g for f in osm if any(t in SEAL for t in f['t'].items()) and not any(t in VEG for t in f['t'].items()) for g in [osm_geom(f)] if g]
    m_seal = rasterize([(g, 1) for g in gs], out_shape=soc.shape, transform=tr, fill=0).astype(bool)

    def stat(geom, steg):
        inne = ~geometry_mask([transform_geom('EPSG:4326', 'EPSG:3006', geom)], soc.shape, tr)
        u = inne & oforseglad
        return dict(ha=round(inne.sum() / 100, 2), ohardgjord_ha=round(u.sum() / 100, 2), markkol_hist=hist(markkol[u], steg) if u.any() else [],
                    markkol_tC=round(float(np.nansum(markkol[u])) * 0.01, 1), biomassa_tC=round(float(bio[u & ~m_seal].sum()) * 0.01, 1))

    exp = json.load(open(os.path.join(ROT, 'data/utbyggnad_op2023.json')))
    omraden = {}
    for o in exp['omraden']:
        g = o['geometry']
        g = json.loads(g.replace("'", '"')) if isinstance(g, str) else g
        omraden[str(o['id'])] = stat(g, 1)

    land = unary_union([make_valid(shape(f['geometry'])) for f in json.load(open(os.path.join(ROT, 'data/land_malmo_osm.json')))['features']])
    deso = {}
    for f in json.load(open(os.path.join(ROT, 'data/deso_2025_malmo.geojson')))['features']:
        klipp = make_valid(shape(f['geometry'])).intersection(land)
        delar = [d for d in getattr(klipp, 'geoms', [klipp]) if d.geom_type == 'Polygon'
                 and shape(transform_geom('EPSG:4326', 'EPSG:3006', mapping(d))).area >= MIN_LANDDEL_M2]
        if not delar:
            deso[f['properties']['id']] = dict(ha=0, ohardgjord_ha=0, markkol_hist=[], markkol_tC=0, biomassa_tC=0)
            continue
        deso[f['properties']['id']] = stat(mapping(MultiPolygon(delar)), 5)

    ut = dict(schema='klimatperspektiv-kol-1',
              kalla='SLU, Carbon stock and carbon stock change in Swedish soils (soc.tif, dom.tif) och biomassalagret (biomass.tif), 10 m; '
                    'bearbetning som i Mulmen65/road2zero-kolkarta',
              enhet='markkol_hist: [t C/ha, antal rutor om 0,01 ha]; markkol_tC och biomassa_tC: ton kol',
              deso=deso, omraden=omraden)
    json.dump(ut, open(os.path.join(ROT, 'data/kol_deso.json'), 'w'), ensure_ascii=False, separators=(',', ':'))
    tot = sum(d['markkol_tC'] + d['biomassa_tC'] for d in deso.values())
    print('klart:', len(deso), 'DeSO,', len(omraden), 'områden; kolförråd i ohårdgjord mark', round(tot / 1000), 'kt C')


if __name__ == '__main__':
    main(sys.argv[1])
