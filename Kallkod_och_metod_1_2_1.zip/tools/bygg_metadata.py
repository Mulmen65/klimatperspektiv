"""Skriver data/metadata.json: byggdatum, källor och kontrollsummor för underlaget. Kör sist:  python tools/bygg_metadata.py"""
import datetime
import hashlib
import json
from pathlib import Path

ROT = Path(__file__).resolve().parents[1]
FILER = ["deso_2025_malmo.geojson", "land_malmo_osm.json", "grund_deso.json", "kol_deso.json", "utbyggnad_op2023.json"]


def main() -> None:
    data = ROT / "data"
    grund = json.loads((data / "grund_deso.json").read_text(encoding="utf-8"))
    kol = json.loads((data / "kol_deso.json").read_text(encoding="utf-8"))
    utb = json.loads((data / "utbyggnad_op2023.json").read_text(encoding="utf-8"))
    meta = {
        "schema": "klimatperspektiv-metadata-1",
        "byggdatum": datetime.date.today().isoformat(),
        "kallor": {
            "grund_deso.json": grund["kalla"],
            "kol_deso.json": kol["kalla"],
            "utbyggnad_op2023.json": utb["kalla"],
            "deso_2025_malmo.geojson": "SCB, DeSO 2025_v2 (via Vägvis och Road2Zero-OP)",
            "land_malmo_osm.json": "OpenStreetMap-bidragsgivare (ODbL), landpolygoner för Malmö (via Road2Zero-OP)",
        },
        "antal": {"deso": len(grund["deso"]), "utbyggnadsomraden": len(utb["omraden"]),
                  "bostader_op2023": sum(a["bostader"] for a in utb["omraden"]),
                  "arbetsplatser_op2023": sum(a["arbetsplatser"] for a in utb["omraden"])},
        "sha256": {f: hashlib.sha256((data / f).read_bytes()).hexdigest() for f in FILER},
    }
    (data / "metadata.json").write_text(json.dumps(meta, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    print("klart:", meta["byggdatum"], meta["antal"])


if __name__ == "__main__":
    main()
