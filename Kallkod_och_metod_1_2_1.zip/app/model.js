/* Klimatperspektiv – beräkningsmotor. Klimatpåverkan per DeSO i Malmö 2024–2050 i fem perspektiv (kartlager):
   Markens klimatvärde, Nyexploatering, Transport & mobilitet, Energi och Cirkularitet.
   Ren JavaScript utan beroenden. Körs i webbläsaren (window.Klimatperspektiv) och i Node (tester).
   Enheter: ton CO2e per år om inget annat anges. Alla antaganden finns i DEFAULTS; källorna står i app.js (FALT) och README. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.Klimatperspektiv = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const VERSION = '1.2.1';
  const BAS = 2024, SLUT = 2050;
  const AR = [2024, 2030, 2035, 2040, 2045, 2050];          // år som går att välja i gränssnittet
  const MIL = [2030, 2035, 2040, 2045, 2050];               // år då användaren anger folkmängden
  const PERIOD = [[2025, 2030], [2031, 2035], [2036, 2040], [2041, 2045], [2046, 2050]];   // byggperioder fram till varje milstolpe
  const ACK = [2025, 2050];
  const C_TO_CO2 = 44 / 12;

  /* Komponenter (ton CO2e per år och DeSO). Varje komponent hör till ett perspektiv; summan av alla räknar ingenting två gånger. */
  const KOMP = ['mark', 'bygg', 'anl', 'omb', 'mob', 'nymob', 'energi', 'nydrift', 'byggdel'];
  const NAMN = {
    byggdel: 'Avgränsat byte eller bevarande av byggdelar', mark: 'Förändrad markanvändning', bygg: 'Nybyggnad (A1–A5) och rivning', anl: 'Grundläggning, gator och ledningar', omb: 'Omvandling, påbyggnad och renovering',
    mob: 'Mobilitet i befintlig stad', nymob: 'Nya invånares mobilitet', energi: 'Energi i befintliga byggnader', nydrift: 'Nya byggnaders energi'
  };
  const KORT = {byggdel: 'Byggdelar (separat)', mark: 'Markanvändning', bygg: 'Nybyggnad', anl: 'Anläggning', omb: 'Omvandling m.m.', mob: 'Mobilitet', nymob: 'Ny mobilitet', energi: 'Energi befintliga', nydrift: 'Energi nya'};
  const PERSPEKTIV = {
    mark: {namn: 'Markens klimatvärde', kort: 'Mark', komp: ['mark'], fraga: 'Vad går förlorat eller förändras när mark tas i anspråk?'},
    ny: {namn: 'Nyexploatering', kort: 'Nyexploatering', komp: ['bygg', 'anl'], fraga: 'Vilken klimatmässig insats krävs för att bygga det som befolkningen behöver?'},
    transport: {namn: 'Transport & mobilitet', kort: 'Transport', komp: ['mob', 'nymob'], fraga: 'Vilket resande bygger lokaliseringen in?'},
    energi: {namn: 'Energi', kort: 'Energi', komp: ['energi', 'nydrift'], fraga: 'Vad kostar byggnadernas el och värme klimatet, i dag och när staden växer?'},
    cirk: {namn: 'Cirkularitet', kort: 'Cirkularitet', komp: ['omb','byggdel'], fraga: 'Vad kan bevaras, användas bättre, byggas om och återbrukas?'}
  };
  const PERSPEKTIV_ID = Object.keys(PERSPEKTIV);

  /* Klimatpåverkan vid uppförande, modul A1–A5, kg CO2e per m² BTA. Boverket (2026b), rapport 2026:29, utkast:
     tabell 2 (referensvärden: median för flerbostadshus och lokaler, 75-percentil för småhus ≥ 130 m²) och tabell 5 (gränsvärden 2030). */
  const BYGG = {referens: {fbh: 358, smahus: 171, lokal: 383}, gransvarde2030: {fbh: 235, smahus: 130, lokal: 250}};
  const P75_PROXY = 1.15;   // hållpunkten 2040 är 90 % under 75-percentilen 2020; den approximeras som referensvärdet × 1,15 (som i Road2Zero-OP)

  /* Emissionsfaktorer över tid, samma värden som i Road2Zero-OP och Road2Zero-Plan: startvärdet gäller till och med 2026
     och från 2027 en årlig förändring i procent per period. */
  const TAKTPERIOD = [[2027, 2030], [2031, 2035], [2036, 2040], [2041, 2045], [2046, 2050]];
  const UTV = {
    el: [-3.54, -2.52, -2.88, -2.09, -2.33],          // EU:s referensscenario 2020
    el_iea: [-6.68, -3.7, -3.7, -3.7, -3.7],          // EU:s och den globala elens klimatfaktor (IEA, 2026)
    el_wem: [-8.2, -1.69, -0.91, 0, 0],               // Sveriges prognos med befintliga styrmedel (Naturvårdsverket, 2025)
    fv: [-1.63, -1.75, -1.92, -2.13, -2.38],          // EU:s referensscenario 2020
    insteg: [-5.71, -5.98, -1.44, -1.53, -1.23],      // SBUF 14381 Insteg (BAU)
    fardplan: [-9.24, -5.92, -1.65, -1.8, -0.97],     // SBUF 14381 Färdplan (BÄST)
    flotta_nv2026: [-4.58, -5.96, -10.95, -7.44, -7.44],   // bränslekedjan per fordonskilometer, beslutade styrmedel (Naturvårdsverket, 2026; Trafikverket, 2026)
    bilprod: [-3.7, -3.7, -3.7, -3.7, -3.7]           // fordonens tillverkning följer den globala elens klimatfaktor (IEA, 2026)
  };
  const EL_ALT = {boverket: {ef: 0.037, takt: UTV.el, namn: 'Boverket'}, iea: {ef: 0.026, takt: UTV.el_iea, namn: 'IEA handelskorrigerad'},
    egen: {ef: null, takt: UTV.el_wem, namn: 'Eget startvärde'}};
  const BECCS = {ar: 2030, minskning: 43};   // Sysavs koldioxidavskiljning, se Road2Zero-OP

  /* Folkmängd. 2030 och 2035 ur Malmö stads prognos 2025–2035, bilaga 1 tabell 1: 381846 respektive 395094. 2040–2050 är en framskrivning med prognosens sista årsökning, 2 660 invånare per år (modellval). */
  const POP_STD = {2030: 381846, 2035: 395094, 2040: 408394, 2045: 421694, 2050: 434994};

  const DEFAULTS = {
    ar: 2050,
    // BOA är bostadsarea; omräkning till modellens BTA anges uttryckligen.
    ytaVal: 'typologi', boaPerPerson: 36.3981042654, boaPerHushall: 76.8, boaAndelBta: 0.8,
    refYtaVal: 'typologi', refBoaPerPerson: 36.3981042654, refBoaPerHushall: 76.8,
    refPersonerPerHushall: 2.11,
    cirkVisning: 'undviket',
    komponentAktiv:'nej', antalByggdelar: 0, efByteByggdel: 0, efBevaraByggdel: 0,
    arByteRef: 2026, arByteAlt: 2051, bevaraByggdel: 'nej', komponentAvgransad: 'nej', kallaByggdel: '', byggdelDeso:'',

    // 1.1: explicita scenarioindata. Effekter är användarval, inte kausala standardeffekter.
    markOxidation: 100, fortAnlKgBta: 0, renEnergiBesparing: 0,
    byteBil2050: 0, belaggningBil: 1.5, alternativGpkm: 0,
    smahusVal: 'auto', lokalaData: {},
    // Befolkning och behov
    pop2030: POP_STD[2030], pop2035: POP_STD[2035], pop2040: POP_STD[2040], pop2045: POP_STD[2045], pop2050: POP_STD[2050],
    personerPerBostad: 2.11,     // Malmö 2024: 365 644 invånare / 172 941 hushåll (SCB via Vägvis)
    andelFbh: 85,                // % av nya bostäder i flerbostadshus, resten småhus (antagande; beståndet 2024: 84 % enligt SCB)
    btaFbh: 90,                  // m² BTA per bostad i flerbostadshus (antagande, som Road2Zero-OP)
    btaSmahus: 130,              // m² BTA per småhus (antagande, som Road2Zero-OP)
    arbPerInv: 0.46,             // arbetsplatser per ny invånare (ÖP 2023: 37 900 arbetsplatser per 38 850 bostäder × 2,11)
    btaArb: 25,                  // m² BTA per arbetsplats (kontor och service; antagande, som Road2Zero-OP)
    skolBtaPerInv: 2.0,          // m² BTA skola och förskola per ny invånare (ÖP 2023: 16 720 platser per 82 000 invånare × 10 m²)
    rivTakt: 0.05,               // % av befintlig BTA som rivs och ersätts per år (antagande)
    // Nybyggnadens klimatpåverkan
    klimatBygg: 'gransvarde2030',  // 'gransvarde2030' | 'trappa' | 'bana' | 'insteg' | 'fardplan' | 'referens' | 'egen'
    refFbh: BYGG.referens.fbh, refSmahus: BYGG.referens.smahus, refLokal: BYGG.referens.lokal,
    gvFbh: BYGG.gransvarde2030.fbh, gvSmahus: BYGG.gransvarde2030.smahus, gvLokal: BYGG.gransvarde2030.lokal,
    byggR1: UTV.insteg[0], byggR2: UTV.insteg[1], byggR3: UTV.insteg[2], byggR4: UTV.insteg[3], byggR5: UTV.insteg[4],
    traAndel: 0,                 // % av nya flerbostadshus och lokaler med trästomme utöver dagens blandning
    traFaktor: 0.64,             // trästommens klimatpåverkan relativt betongstomme (233,6 / 365 kg/m², Malmqvist m.fl. 2023 och SBUF 14381)
    efRivning: 7,                // kg CO2e per m² BTA som rivs (IVL, 2022: 1–26, de flesta 4–9)
    grundKgBta: 26,              // grundläggning (pålning) per m² BTA som nybyggs, kg CO2e (branschschablon, som i Road2Zero-Plan)
    anlKgMark: 15,               // gator, ledningar och allmän plats per m² utvecklad mark i utbyggnadsområden, kg CO2e (antagande)
    // Lokalisering av nybyggnaden
    lokUtb: 70,                  // % av nybyggnaden i ÖP 2023:s utbyggnadsområden, resten förtätning i befintlig stad (antagande)
    omrOrdning: 'proportionell', // utbyggnadsområdenas ordning: 'proportionell' | 'fokus' | 'klimat'
    fortFordelning: 'jamn',      // förtätningens fördelning på DeSO: 'jamn' (efter folkmängd) | 'bilsnal' (lågt bilinnehav prioriteras)
    fortMarkAndel: 0,            // % av förtätningen som tar ohårdgjord mark i anspråk
    // Cirkularitet (stegmodell). 0 = referens: hela behovet nybyggs.
    suffBefintligt: 0,           // % av nya invånare som ryms i befintligt bestånd
    suffBoyta: 0,                // % lägre BTA per ny bostad
    suffLokal: 0,                // % lägre lokalyta per ny invånare
    omvAndel: 0,                 // % av bostadsbehovet (BTA) som möts genom omvandling av lokaler till bostäder
    omvTak: 10,                  // högst så stor andel (%) av befintlig lokalyta kan omvandlas till 2050
    efOmv: 100,                  // kg CO2e per m² BTA vid omvandling (IVL, 2022: 40–160)
    pabAndel: 0,                 // % av bostadsbehovet som möts genom påbyggnad
    pabTak: 5,                   // högst så stor andel (%) av befintliga flerbostadshus yta kan byggas på till 2050
    pabFaktor: 0.7,              // påbyggnadens klimatpåverkan relativt nybyggnad (antagande: grund och källare utgår)
    renoveraAndel: 0,            // % av rivningarna som ersätts av renovering
    efRenovering: 100,           // kg CO2e per m² BTA vid genomgripande renovering (IVL, 2022: 40–160)
    aterbrukAndel: 0,            // % av nybyggnadens material (räknat i klimatpåverkan) som är återbrukat
    aterbrukBesparing: 80,       // % lägre klimatpåverkan för återbrukat material än för nytt (antagande)
    // Transport & mobilitet
    perspektiv: 'A',             // A: trafik inom området, B: hushållens bilar (Vägvis)
    flottaVal: 'nv2026',         // 'nv2026' | 'oforandrad' | 'egen'
    flotta2030: 1, flotta2040: 1, flotta2050: 1,
    trafikForandring2050: 0,     // % förändrat trafikarbete i befintlig stad till 2050 (linjärt)
    bilFaktorUtb: 1,             // bilar per nytt hushåll i utbyggnadsområden relativt värd-DeSO 2024
    bilFaktorBef: 1,             // bilar per nytt hushåll i befintlig stad (förtätning, omvandling, påbyggnad) relativt värd-DeSO
    andelKmInomMalmo: 0.5,       // andel av nya bilars körsträcka på Malmös vägar (modell A; antagande)
    // Energi
    elVal: 'boverket', efEl: 0.037, efElEgen: 0.037, efFv: 0.056,
    elR1: UTV.el[0], elR2: UTV.el[1], elR3: UTV.el[2], elR4: UTV.el[3], elR5: UTV.el[4],
    fvR1: UTV.fv[0], fvR2: UTV.fv[1], fvR3: UTV.fv[2], fvR4: UTV.fv[3], fvR5: UTV.fv[4],
    beccs: 'nej', beccsAr: BECCS.ar, beccsMinskning: BECCS.minskning,
    effektivisering2050: 0,      // % lägre levererad energi i befintligt bestånd 2050 (linjärt)
    atempNy: 0.9, energiNy: 50, elandelNy: 0.22,   // nya byggnader: Atemp/BTA, kWh/m² Atemp och år, elandel (Road2Zero-OP)
    // Markens klimatvärde (parametrar som i road2zero-kolkarta)
    kolKvar: 22,                 // t C/ha som finns kvar under bebyggd mark (Länsstyrelsen i Uppsala län, 2025)
    tathetFbh: 64, ohardSlutFbh: 0.20,       // bostäder per ha och ohårdgjord andel i slutläget, tät blandad stad (mätt i Malmö)
    tathetSmahus: 11, ohardSlutSmahus: 0.71, // samma för småhus (mätt i Malmö)
    arbEkv: 0.278,               // en arbetsplats i bostadsekvivalenter (25 / 90 m² BTA)
    verksHela: 'ja'              // verksamhetsområden tar hela den ohårdgjorda ytan
  };

  const CIRK = ['suffBefintligt', 'suffBoyta', 'suffLokal', 'omvAndel', 'pabAndel', 'renoveraAndel', 'aterbrukAndel'];
  /* Exempel på stegmodeller. De är räkneexempel, inte prognoser. */
  const CIRK_NIVA = {
    referens: {suffBefintligt: 0, suffBoyta: 0, suffLokal: 0, omvAndel: 0, pabAndel: 0, renoveraAndel: 0, aterbrukAndel: 0},
    mattlig: {suffBefintligt: 5, suffBoyta: 5, suffLokal: 10, omvAndel: 10, pabAndel: 5, renoveraAndel: 50, aterbrukAndel: 10},
    ambitios: {suffBefintligt: 10, suffBoyta: 10, suffLokal: 20, omvAndel: 20, pabAndel: 10, renoveraAndel: 80, aterbrukAndel: 25}
  };
  /* Alternativa befolkningsbanor: prognosens ökning från 2024 (365 644 invånare) gånger en faktor. Räkneexempel, inte prognoser. */
  const POP_BAS = 365644;
  const popNiva = k => Object.fromEntries(MIL.map(m => [m, Math.round(POP_BAS + k * (POP_STD[m] - POP_BAS))]));
  const POP_NIVA = {prognos: POP_STD, lag: popNiva(0.5), hog: popNiva(1.5)};

  const pct = [0, 100];
  const LIMITS = {
    boaPerPerson: [5,250], boaPerHushall: [10,1000], boaAndelBta: [0.3,1],
    refBoaPerPerson: [5,250], refBoaPerHushall: [10,1000], refPersonerPerHushall: [0.5,10],
    antalByggdelar: [0,1e7], efByteByggdel: [0,1e7], efBevaraByggdel: [0,1e7], arByteRef: [2025,2100], arByteAlt: [2025,2100],
    markOxidation: pct, fortAnlKgBta: [0, 1000], renEnergiBesparing: pct,
    byteBil2050: pct, belaggningBil: [1, 8], alternativGpkm: [0, 2000],
    pop2030: [1e5, 2e6], pop2035: [1e5, 2e6], pop2040: [1e5, 2e6], pop2045: [1e5, 2e6], pop2050: [1e5, 2e6],
    personerPerBostad: [0.5, 10], andelFbh: pct, btaFbh: [10, 1000], btaSmahus: [10, 1000], arbPerInv: [0, 5], btaArb: [0, 2000],
    skolBtaPerInv: [0, 100], rivTakt: [0, 5],
    refFbh: [0, 2000], refSmahus: [0, 2000], refLokal: [0, 2000], gvFbh: [0, 2000], gvSmahus: [0, 2000], gvLokal: [0, 2000],
    traAndel: pct, traFaktor: [0, 2], efRivning: [0, 500], grundKgBta: [0, 500], anlKgMark: [0, 500],
    lokUtb: pct, fortMarkAndel: pct,
    suffBefintligt: pct, suffBoyta: [0, 90], suffLokal: pct, omvAndel: pct, omvTak: pct, efOmv: [0, 2000], pabAndel: pct, pabTak: pct,
    pabFaktor: [0, 2], renoveraAndel: pct, efRenovering: [0, 2000], aterbrukAndel: pct, aterbrukBesparing: pct,
    flotta2030: [0, 3], flotta2040: [0, 3], flotta2050: [0, 3], trafikForandring2050: [-100, 200], bilFaktorUtb: [0, 5], bilFaktorBef: [0, 5],
    andelKmInomMalmo: [0, 1],
    efEl: [0, 2], efElEgen: [0, 2], efFv: [0, 2], beccsAr: [2025, 2050], beccsMinskning: pct, effektivisering2050: [-100, 100],
    atempNy: [0.3, 1.2], energiNy: [0, 500], elandelNy: [0, 1],
    kolKvar: [0, 1000], tathetFbh: [1, 1000], ohardSlutFbh: [0, 1], tathetSmahus: [0.1, 200], ohardSlutSmahus: [0, 1], arbEkv: [0, 5],
    ...Object.fromEntries(['elR', 'fvR', 'byggR'].flatMap(p => [1, 2, 3, 4, 5].map(k => [p + k, [-50, 50]])))
  };
  const ENUMS = {ytaVal:['typologi','person','hushall'], refYtaVal:['typologi','person','hushall'], cirkVisning:['undviket','minus','netto'], komponentAktiv:['nej','ja'], bevaraByggdel:['nej','ja'], komponentAvgransad:['nej','ja'],smahusVal: ['auto','egen'],
    klimatBygg: ['gransvarde2030', 'trappa', 'bana', 'insteg', 'fardplan', 'referens', 'egen'], omrOrdning: ['proportionell', 'fokus', 'klimat'],
    fortFordelning: ['jamn', 'bilsnal'], perspektiv: ['A', 'B'], flottaVal: ['nv2026', 'oforandrad', 'egen'], elVal: ['boverket', 'iea', 'egen'],
    beccs: ['nej', 'ja'], verksHela: ['ja', 'nej']
  };

  const LOCAL_FIELDS = {kmPerBil:[0,100000], bilarPerHushall:[0,5],
    kwhEl:[0,1e10], kwhFv:[0,1e10]};
  function validateLocal(rows) {
    if (!rows || typeof rows !== 'object' || Array.isArray(rows)) throw new Error('lokalaData ska vara ett objekt per DeSO');
    const out = {};
    for (const [id,r] of Object.entries(rows)) {
      if (!/^1280[A-C][0-9]{4}$/.test(id) || !r || typeof r !== 'object') throw new Error('Ogiltig DeSO: '+id);
      if (typeof r.kalla !== 'string' || !r.kalla.trim() || r.ar !== 2024) throw new Error('Källa och basår 2024 krävs för '+id);
      out[id] = {kalla:r.kalla.trim(),ar:2024};
      for (const [k,v] of Object.entries(r)) {
        if (['kalla','ar'].includes(k)) continue;
        if (!(k in LOCAL_FIELDS)) throw new Error('Okänd lokal parameter: '+k);
        const [lo,hi]=LOCAL_FIELDS[k];
        if (typeof v !== 'number' || !Number.isFinite(v) || v<lo || v>hi) throw new Error('Ogiltigt värde för '+id+' '+k);
        out[id][k]=v;
      }
    }
    return out;
  }
  function params(p = {}) {
    const out = {...DEFAULTS}, inp = p || {};
    for (const [k, v] of Object.entries(inp)) {
      if (!(k in DEFAULTS)) continue;
      if (k === 'kallaByggdel' || k === 'byggdelDeso') {out[k]=String(v??'').slice(0,1500);continue;}
      if (k === 'lokalaData') {out[k] = validateLocal(v);continue;}
      if (k in ENUMS) { if (ENUMS[k].includes(v)) out[k] = v; continue; }
      if (k === 'ar') { const y = v === 'ack' ? 'ack' : Number(v); if (y === 'ack' || AR.includes(y)) out[k] = y; continue; }
      const x = typeof v === 'string' ? Number(v.replace(',', '.').replace(/\s/g, '')) : v;
      if (typeof x !== 'number' || !Number.isFinite(x)) continue;
      const [lo, hi] = LIMITS[k] || [-Infinity, Infinity];
      out[k] = Math.min(hi, Math.max(lo, x));
    }
    const har = k => k in inp && inp[k] !== undefined && inp[k] !== null && inp[k] !== '';
    for (let k = 1; k <= 5; k++) if (!har('elR' + k)) out['elR' + k] = EL_ALT[out.elVal].takt[k - 1];
    out.efEl = out.elVal === 'egen' ? out.efElEgen : EL_ALT[out.elVal].ef;
    out.arByteRef=Math.round(out.arByteRef);out.arByteAlt=Math.round(out.arByteAlt);
    return out;
  }
  /* Samma antaganden utan cirkulära åtgärder: hela behovet nybyggs. Används som jämförelse (referens). */
  const utanCirk = P => ({...P, ...CIRK_NIVA.referens, ytaVal:P.refYtaVal, boaPerPerson:P.refBoaPerPerson, boaPerHushall:P.refBoaPerHushall, personerPerBostad:P.refPersonerPerHushall, bevaraByggdel:'nej'});
  const harCirk = P => CIRK.some(k => P[k] > 0) || (P.komponentAktiv==='ja' && P.bevaraByggdel==='ja') || Math.abs(housing(P).btaHh-housing(utanCirk(P)).btaHh)>1e-8 || P.personerPerBostad!==P.refPersonerPerHushall;

  function housing(P) {
    const a=P.andelFbh/100, weighted=a*P.btaFbh+(1-a)*P.btaSmahus;
    const boaHh=P.ytaVal==='person'?P.boaPerPerson*P.personerPerBostad:P.ytaVal==='hushall'?P.boaPerHushall:weighted*(1-P.suffBoyta/100)*P.boaAndelBta;
    const btaHh=boaHh/P.boaAndelBta, scale=weighted>0?btaHh/weighted:0;
    return {boaHh,boaPerson:boaHh/P.personerPerBostad,btaHh,fbh:P.btaFbh*scale,smahus:P.btaSmahus*scale};
  }
  function circularComparison(S,R,Rref,ar='ack') {
    const a=view(S,R,ar), b=view(S,Rref,ar);
    const rows=a.rows.map((r,i)=>{
      const q=b.rows[i], byggRef=q.bygg_tot,byggVal=r.bygg_tot,markRef=q.mark,markVal=r.mark;
      return {id:r.id,byggRef,byggVal,markRef,markVal,undviketBygg:byggRef-byggVal,undviketMark:markRef-markVal,
        undviket:byggRef+markRef-byggVal-markVal,bidrag:byggVal+markVal-byggRef-markRef,
        undviketEnergi:q.energi_tot-r.energi_tot,undviketTransport:q.mob_tot-r.mob_tot,undviketTotalt:q.total-r.total};
    });
    const city={};for(const k of Object.keys(rows[0]||{}).filter(k=>k!=='id'))city[k]=rows.reduce((s,r)=>s+r[k],0);
    return {rows,city,ar,refArea:housing(Rref.P),area:housing(R.P)};
  }
  function circularAttribution(S,P,ar='ack') {
    let q=utanCirk(P),prev=compute(S,q);const ref=prev,out=[];
    const metric=R=>{const v=view(S,R,ar).city;return v.bygg_tot+v.mark;};
    const steps=[['Yta och hushållsstorlek',['ytaVal','boaPerPerson','boaPerHushall','personerPerBostad','suffBoyta']],
      ['Befintligt bestånd och lokalyta',['suffBefintligt','suffLokal']],['Omvandling',['omvAndel']],['Påbyggnad',['pabAndel']],
      ['Renovering i stället för rivning',['renoveraAndel']],['Materialåterbruk',['aterbrukAndel']],['Bevarande av separat byggdel',['bevaraByggdel']]];
    for(const [namn,keys] of steps){q={...q,...Object.fromEntries(keys.map(k=>[k,P[k]]))};const next=compute(S,q);out.push({namn,besparing:metric(prev)-metric(next)});prev=next;}
    return {rows:out,summa:out.reduce((s,x)=>s+x.besparing,0),referens:metric(ref),alternativ:metric(prev)};
  }
  const clamp01 = x => Math.max(0, Math.min(1, x));
  const ramp = y => clamp01((y - BAS) / (SLUT - BAS));
  /* Index för en faktor med årlig förändring per period: 1 till och med 2026, därefter (1 + r/100) per år. */
  function indexAr(takter, y) {
    let I = 1;
    for (let t = 2027; t <= Math.min(y, SLUT); t++) I *= 1 + takter[TAKTPERIOD.findIndex(([a, b]) => t >= a && t <= b)] / 100;
    return I;
  }
  const takter = (P, pre) => [1, 2, 3, 4, 5].map(k => P[pre + k]);
  function fleet(P, y) {
    const pts = [[BAS, 1], [2030, P.flotta2030], [2040, P.flotta2040], [2050, P.flotta2050]];
    if (y <= BAS) return 1;
    for (let i = 1; i < pts.length; i++) { const [x0, v0] = pts[i - 1], [x1, v1] = pts[i]; if (y <= x1) return v0 + (v1 - v0) * (y - x0) / (x1 - x0); }
    return pts[pts.length - 1][1];
  }
  const flottaIndex = (P, y) => P.flottaVal === 'oforandrad' ? 1 : P.flottaVal === 'egen' ? fleet(P, y) : indexAr(UTV.flotta_nv2026, y);
  const bilprodIndex = (P, y) => P.flottaVal === 'nv2026' ? indexAr(UTV.bilprod, y) : flottaIndex(P, y);
  /* Emissionsfaktorer för el och fjärrvärme ett visst år, kg CO2e/kWh. */
  function faktorer(P, y) {
    const iEl = indexAr(takter(P, 'elR'), y), beccs = P.beccs === 'ja' && y >= P.beccsAr ? 1 - P.beccsMinskning / 100 : 1;
    const iFv = indexAr(takter(P, 'fvR'), y) * beccs;
    return {iEl, iFv, el: P.efEl * iEl, fv: P.efFv * iFv};
  }
  /* Klimatpåverkan vid uppförande, kg CO2e/m² BTA (A1–A5), för byggnadstyp ('fbh' | 'smahus' | 'lokal') och år.
     Trapporna som bygger på gränsvärden använder dagens referensvärde fram till 2029, eftersom gränsvärdena föreslås gälla från 2030. */
  const TYPNYCKEL = {fbh: 'Fbh', smahus: 'Smahus', lokal: 'Lokal'};
  function byggFaktor(P, typ, y) {
    let ref = P['ref' + TYPNYCKEL[typ]], gv = P['gv' + TYPNYCKEL[typ]];
    if (typ === 'smahus' && P.smahusVal === 'auto') {
      const liten = housing(P).smahus * P.atempNy < 130;
      ref = liten ? 196 : 171; gv = liten ? 150 : 130;
    }
    const m2040 = 0.1 * ref * P75_PROXY;
    switch (P.klimatBygg) {
      case 'referens': return ref;
      case 'gransvarde2030': return y < 2030 ? ref : gv;
      case 'trappa': return y < 2030 ? ref : y < 2035 ? gv : y < 2040 ? (gv + m2040) / 2 : m2040;
      case 'bana': return y < 2030 ? ref : y >= 2040 ? m2040 : gv + (m2040 - gv) * (y - 2030) / 10;
      case 'insteg': return ref * indexAr(UTV.insteg, y);
      case 'fardplan': return ref * indexAr(UTV.fardplan, y);
      case 'egen': return ref * indexAr(takter(P, 'byggR'), y);
      default: return gv;
    }
  }
  /* Folkmängd ett visst år: linjärt mellan 2024 (underlaget) och användarens värden 2030, 2035, 2040, 2045 och 2050. */
  function folkmangd(P, bas, y) {
    const pts = [[BAS, bas], ...MIL.map(m => [m, P['pop' + m]])];
    if (y <= BAS) return bas;
    for (let i = 1; i < pts.length; i++) { const [x0, v0] = pts[i - 1], [x1, v1] = pts[i]; if (y <= x1) return v0 + (v1 - v0) * (y - x0) / (x1 - x0); }
    return pts[pts.length - 1][1];
  }
  /* Kol per hektar ohårdgjord mark som går förlorat när marken bebyggs, t C/ha: max(0, markkol − kvarvarande kol) + biomassa. */
  function kolPerHa(Au, hist, bio, kvar) {
    if (!(Au > 0)) return 0;
    let c = 0; for (const [v, antal] of hist) c += antal * Math.max(0, v - kvar) * 0.01;
    return (c + bio) / Au;
  }
  /* Markanspråk per bostadsekvivalent (ha) och ohårdgjord andel i slutläget för den valda blandningen av flerbostadshus och småhus. */
  function typologi(P) {
    const aF = P.andelFbh / 100, lF = aF / P.tathetFbh, lS = (1 - aF) / P.tathetSmahus, ha = lF + lS;
    return {ha, uSlut: ha > 0 ? (lF * P.ohardSlutFbh + lS * P.ohardSlutSmahus) / ha : P.ohardSlutFbh};
  }

  /* Förbered underlaget en gång. D = {deso (GeoJSON), grund, kol, utb}. */
  function prepare(D) {
    const ids = D.deso.features.map(f => f.properties.id), n = ids.length, index = Object.fromEntries(ids.map((id, i) => [id, i]));
    const g = D.grund, apb = g.energi.atemp_per_bta || 0.9, arr = () => new Float64Array(n);
    const S = {ids, index, n, D, namn: [], landHa: arr(), bef: arr(), hh: arr(), bil: arr(), kwhEl: arr(), kwhFv: arr(), atemp: arr(), eLo: arr(), eHi: arr(),
      btaFbh: arr(), btaSmahus: arr(), btaLokal: arr(), btaInd: arr(), btaTot: arr(),
      A: {fuel: arr(), el: arr(), fordon: arr(), vkm: arr(), lo: arr(), hi: arr()}, B: {fuel: arr(), el: arr(), fordon: arr(), vkm: arr(), lo: arr(), hi: arr()},
      cph: arr(), km: arr(), epvFuel: arr(), epvEl: arr(), epvFordon: arr(), Au: arr(), kolYta: arr(), markkolC: arr(), bioC: arr(), hist: []};
    const st = g.mobilitet.stad, sB = st.B;
    S.cityCph = sB.cars / sB.hushall; S.cityKm = sB.vkm / sB.cars; S.cityAvkm = st.A.vkm;
    S.elV = (g.mobilitet.el_g_per_kwh && g.mobilitet.el_g_per_kwh.A) || 90;   // elens klimatfaktor i Vägvis, g CO2e/kWh
    ids.forEach((id, i) => {
      const d = g.deso[id]; if (!d) throw new Error('Grunddata saknas för ' + id);
      S.namn.push(d.namn); S.landHa[i] = d.land_ha || 0; S.bef[i] = d.bef; S.hh[i] = d.hh; S.bil[i] = d.bil;
      S.kwhEl[i] = d.energi.kwh_el; S.kwhFv[i] = d.energi.kwh_fv; S.atemp[i] = d.energi.atemp; S.eLo[i] = d.energi.lo; S.eHi[i] = d.energi.hi;
      S.btaFbh[i] = d.atemp.flerbostadshus / apb; S.btaSmahus[i] = d.atemp.smahus / apb; S.btaLokal[i] = d.atemp.lokal / apb;
      S.btaInd[i] = (d.atemp.industri + (d.atemp.okand || 0)) / apb; S.btaTot[i] = S.btaFbh[i] + S.btaSmahus[i] + S.btaLokal[i] + S.btaInd[i];
      for (const m of ['A', 'B']) for (const k of ['fuel', 'el', 'fordon', 'vkm', 'lo', 'hi']) S[m][k][i] = d[m][k];
      S.cph[i] = d.hh > 0 && d.bil >= 0 ? d.bil / d.hh : S.cityCph;
      const b = d.B, ok = b.vkm > 0 && b.cars > 0, v = ok ? b : sB;
      S.km[i] = ok ? b.vkm / b.cars : S.cityKm;
      S.epvFuel[i] = v.fuel / v.vkm; S.epvEl[i] = v.el / v.vkm; S.epvFordon[i] = v.fordon / v.vkm;
      const k = D.kol.deso[id] || {ha: 0, ohardgjord_ha: 0, markkol_hist: [], markkol_tC: 0, biomassa_tC: 0};
      S.Au[i] = k.ohardgjord_ha; S.kolYta[i] = k.ha; S.markkolC[i] = k.markkol_tC; S.bioC[i] = k.biomassa_tC; S.hist.push(k.markkol_hist);
    });
    const sum = a => a.reduce((x, y) => x + y, 0);
    S.bef0 = sum(S.bef); S.btaBef = sum(S.btaTot); S.btaLokalTot = sum(S.btaLokal); S.btaFbhTot = sum(S.btaFbh);
    S.bostAndel = (sum(S.btaFbh) + sum(S.btaSmahus)) / S.btaBef;   // bostädernas andel av befintlig yta
    S.areas = D.utb.omraden.map(a => {
      const delar = a.delar.filter(d => d.deso in index), tot = delar.reduce((s, d) => s + d.andel, 0) || 1;
      const k = D.kol.omraden[String(a.id)] || {ohardgjord_ha: 0, markkol_hist: [], biomassa_tC: 0};
      return {id: a.id, namn: a.namn, kategori: a.kategori, fokus: a.fokus, bostader: a.bostader, arbetsplatser: a.arbetsplatser, ha: a.ha,
        delar: delar.map(d => ({i: index[d.deso], andel: d.andel / tot})), Au: k.ohardgjord_ha, hist: k.markkol_hist, bio: k.biomassa_tC};
    });
    return S;
  }

  const norm = w => { const s = w.reduce((x, y) => x + y, 0); return s > 0 ? Float64Array.from(w, x => x / s) : new Float64Array(w.length); };

  /* Huvudberäkning. Returnerar årsvärden 2024–2050 per DeSO och komponent, och stadens flöden år för år. */
  function compute(S, pIn) {
    const P = params(pIn);
    if(P.komponentAktiv==='ja' && P.antalByggdelar>0 && (P.komponentAvgransad!=='ja' || !P.kallaByggdel.trim()))throw new Error('Byggdelar kräver källa och bekräftad avgränsning från övriga byggfaktorer');
    if (Object.keys(P.lokalaData).length) {
      const lokal = P.lokalaData;
      for (const id of Object.keys(lokal)) if (!(id in S.index)) throw new Error('DeSO saknas i kartunderlaget: '+id);
      S = {...S, cph:Float64Array.from(S.cph), km:Float64Array.from(S.km),
        kwhEl:Float64Array.from(S.kwhEl), kwhFv:Float64Array.from(S.kwhFv),
        B:Object.fromEntries(Object.entries(S.B).map(([k,v])=>[k,Float64Array.from(v)]))};
      for (const [id,r] of Object.entries(lokal)) {
        const i=S.index[id], c=r.bilarPerHushall ?? S.cph[i], km=r.kmPerBil ?? S.km[i], vkm=S.hh[i]*c*km;
        S.cph[i]=c;S.km[i]=km;
        for (const k of ['fuel','el','fordon','lo','hi']) S.B[k][i]=S.B.vkm[i]>0?S.B[k][i]*vkm/S.B.vkm[i]:0;
        S.B.fuel[i]=S.epvFuel[i]*vkm;S.B.el[i]=S.epvEl[i]*vkm;S.B.fordon[i]=S.epvFordon[i]*vkm;S.B.vkm[i]=vkm;
        if ('kwhEl' in r) S.kwhEl[i]=r.kwhEl;
        if ('kwhFv' in r) S.kwhFv[i]=r.kwhFv;
      }
    }
    if(P.byggdelDeso && !(P.byggdelDeso in S.index))throw new Error('Okänd DeSO för byggdelar');
    if(P.bevaraByggdel==='ja'&&P.arByteAlt<P.arByteRef)throw new Error('Alternativets senare utbyte får inte ligga före referensens');
    const n = S.n, years = []; for (let y = BAS; y <= SLUT; y++) years.push(y);
    const comp = {}; for (const c of KOMP) comp[c] = years.map(() => new Float64Array(n));
    const pop = years.map(() => new Float64Array(n)), nyaInv = years.map(() => new Float64Array(n)), nyBta = years.map(() => new Float64Array(n));

    // faktorer per år
    const T = years.map(y => {
      const fl = flottaIndex(P, y), fk = faktorer(P, y), f = ramp(y), kEl = fk.el * 1000 / S.elV * (P.flottaVal === 'nv2026' ? 1 : fl);
      return {y, fl, ip: bilprodIndex(P, y), kEl, fk, tr: 1 + P.trafikForandring2050 / 100 * f, eff: 1 - P.effektivisering2050 / 100 * f,
        mixNy: P.elandelNy * fk.el + (1 - P.elandelNy) * fk.fv, iAnl: indexAr(UTV.insteg, y), fF: byggFaktor(P, 'fbh', y), fS: byggFaktor(P, 'smahus', y), fL: byggFaktor(P, 'lokal', y)};
    });
    const epv = (i, t) => S.epvFuel[i] * t.fl + S.epvEl[i] * t.kEl + S.epvFordon[i] * t.ip;   // t CO2e per fordonskilometer för nya bilar
    const tra = 1 - P.traAndel / 100 * (1 - P.traFaktor), ab = 1 - P.aterbrukAndel / 100 * P.aterbrukBesparing / 100;

    // statiska värden per DeSO
    const ty = typologi(P), Cu = new Float64Array(n), risk = new Float64Array(n), trafikHh = new Float64Array(n);
    for (let i = 0; i < n; i++) {
      Cu[i] = kolPerHa(S.Au[i], S.hist[i], S.bioC[i], P.kolKvar); risk[i] = (1 - ty.uSlut) * Cu[i] * C_TO_CO2 * P.markOxidation/100;
      for (const t of T) if (t.y >= ACK[0]) trafikHh[i] += S.cph[i] * S.km[i] * (epv(i,t)*(1-P.byteBil2050/100*ramp(t.y))+P.byteBil2050/100*ramp(t.y)*P.belaggningBil*P.alternativGpkm/1e6);
    }

    // utbyggnadsområden
    const areas = S.areas.map(a => {
      const verks = a.kategori === 'Verksamhetsområde', neq = a.bostader + P.arbEkv * a.arbetsplatser, CuA = kolPerHa(a.Au, a.hist, a.bio, P.kolKvar);
      const tagen = verks && P.verksHela === 'ja' ? a.Au : Math.min(a.Au, neq * ty.ha), uSlut = verks ? P.ohardSlutFbh : ty.uSlut;
      const L = tagen * (1 - uSlut) * CuA * C_TO_CO2 * P.markOxidation/100;
      const trafik = a.delar.reduce((s, d) => s + d.andel * trafikHh[d.i], 0) * P.bilFaktorUtb;
      return {...a, verks, neq, Cu: CuA, tagen, L, trafik, poang: trafik + (neq > 0 ? L / neq : 0), dw: 0, arb: 0, f: 0, mark: 0};
    });
    const bostOmr = areas.map((a, k) => k).filter(k => areas[k].bostader > 0);
    const grupper = P.omrOrdning === 'fokus' ? [bostOmr.filter(k => areas[k].fokus === 1), bostOmr.filter(k => areas[k].fokus !== 1)]
      : P.omrOrdning === 'klimat' ? bostOmr.slice().sort((a, b) => areas[a].poang - areas[b].poang).map(k => [k]) : [bostOmr];
    const arbTot = areas.reduce((s, a) => s + a.arbetsplatser, 0);

    // fördelningsnycklar
    const wFort = norm(S.ids.map((_, i) => P.fortFordelning === 'bilsnal' ? S.bef[i] / Math.pow(Math.max(0.05, S.cph[i]), 2) : S.bef[i]));
    const wLok = norm(S.ids.map((_, i) => S.btaLokal[i] + S.btaInd[i])), wOmv = norm(S.btaLokal), wPab = norm(S.btaFbh), wBest = norm(S.btaTot), wBef = norm(S.bef);

    const aF = P.andelFbh / 100, s1 = P.suffBefintligt / 100, s2 = P.suffBoyta / 100, s3 = P.suffLokal / 100;
    const hArea=housing(P), bFbh = hArea.fbh, bSm = hArea.smahus, lokPerInv = P.arbPerInv * P.btaArb + P.skolBtaPerInv;
    const takOmv = P.omvTak / 100 * S.btaLokalTot, takPab = P.pabTak / 100 * S.btaFbhTot;
    let cumOmv = 0, cumPab = 0, popForra = S.bef0;
    const retired = new Float64Array(n), renovated = new Float64Array(n), usedFort = new Float64Array(n);
    const hhUtb = new Float64Array(n), hhBef = new Float64Array(n), cumInv = new Float64Array(n), cumAtemp = new Float64Array(n), cumBta = new Float64Array(n);
    const stad = [];

    years.forEach((y, yi) => {
      const t = T[yi], popY = folkmangd(P, S.bef0, y), dPop = yi === 0 ? 0 : popY - popForra, N = Math.max(0, dPop);
      // behov
      const invSuff = N * s1, bost = (N - invSuff) / P.personerPerBostad;
      const behovFbh = bost * aF * bFbh, behovSm = bost * (1 - aF) * bSm, btaBost = behovFbh + behovSm;
      const onskOmv = btaBost * P.omvAndel / 100, onskPab = btaBost * P.pabAndel / 100;
      const omv = Math.max(0, Math.min(onskOmv, takOmv - cumOmv, behovFbh)), pab = Math.max(0, Math.min(onskPab, takPab - cumPab, behovFbh - omv));
      cumOmv += omv; cumPab += pab;
      const nyFbh = behovFbh - omv - pab, dwOmv = bFbh > 0 ? omv / bFbh : 0, dwPab = bFbh > 0 ? pab / bFbh : 0, dwFbh = bFbh > 0 ? nyFbh / bFbh : 0, dwSm = bost * (1 - aF), dwNy = dwFbh + dwSm;
      const nyLok = N * lokPerInv * (1 - s3);
      const riv = yi === 0 ? 0 : P.rivTakt / 100 * S.btaBef, ren = riv * P.renoveraAndel / 100, ers = riv - ren;
      const brutto = N / P.personerPerBostad * (P.ytaVal==='typologi' ? aF * P.btaFbh + (1 - aF) * P.btaSmahus : hArea.btaHh) + N * lokPerInv;

      // lokalisering av nybyggda bostäder: utbyggnadsområden (med kapacitet) och förtätning
      let behovUtb = dwNy * P.lokUtb / 100, dwFort = dwNy - behovUtb, dwUtb = 0;
      const dwOmr = new Float64Array(areas.length);
      for (const grp of grupper) {
        if (behovUtb <= 1e-12) break;
        const kvar = grp.map(k => Math.max(0, areas[k].bostader - areas[k].dw)), sumKvar = kvar.reduce((a, b) => a + b, 0);
        if (sumKvar <= 0) continue;
        const tar = Math.min(behovUtb, sumKvar);
        grp.forEach((k, q) => { dwOmr[k] += tar * kvar[q] / sumKvar; });
        behovUtb -= tar; dwUtb += tar;
      }
      const fullt = behovUtb > 1e-9 ? behovUtb : 0; dwFort += fullt;   // utbyggnadsområdena är fulla: resten blir förtätning
      const lokUtb = arbTot > 0 ? nyLok * P.lokUtb / 100 : 0, lokFort = nyLok - lokUtb;

      const dw = new Float64Array(n), lok = new Float64Array(n), utv = new Float64Array(n), mark = comp.mark[yi];
      areas.forEach((a, k) => {
        const lokA = arbTot > 0 ? lokUtb * a.arbetsplatser / arbTot : 0;
        a.dw += dwOmr[k]; a.arb += P.btaArb > 0 ? lokA / P.btaArb : 0;
        const f = a.neq > 0 ? Math.min(1, (a.dw + P.arbEkv * Math.min(a.arbetsplatser, a.arb)) / a.neq) : 0, fForra = a.f, dMark = a.L * (f - a.f);
        a.f = f; a.mark += dMark;
        for (const d of a.delar) { dw[d.i] += dwOmr[k] * d.andel; lok[d.i] += lokA * d.andel; mark[d.i] += dMark * d.andel; utv[d.i] += (f - fForra) * a.ha * d.andel; hhUtb[d.i] += dwOmr[k] * d.andel; }
      });
      const rF = dwNy > 0 ? dwFbh / dwNy : 0, rest = dPop < 0 ? dPop : 0;   // minskar folkmängden fördelas minskningen efter befintlig folkmängd
      let sB = 0, sO = 0, sM = 0, sA = 0, sU = 0, sVkm = 0;
      for (let i = 0; i < n; i++) {
        const dF = dwFort * wFort[i], dO = dwOmv * wOmv[i], dP = dwPab * wPab[i], iS = invSuff * wBef[i];
        dw[i] += dF; lok[i] += lokFort * wLok[i];
        // Förtätningens markanspråk begränsas till kvarvarande ohårdgjord yta utanför utbyggnadsområdenas hela footprint.
        const reserved = areas.reduce((v,a)=>v+a.delar.filter(d=>d.i===i).reduce((z,d)=>z+a.Au*d.andel,0),0);
        const fortHa = Math.min(Math.max(0,S.Au[i]-reserved-usedFort[i]),dF*ty.ha*P.fortMarkAndel/100);
        usedFort[i] += fortHa; mark[i] += fortHa*risk[i];
        hhBef[i] += dF + dO + dP + iS / P.personerPerBostad;
        cumInv[i] += (dw[i] + dO + dP) * P.personerPerBostad + iS + rest * wBef[i];
        const bF = dw[i] * rF * bFbh, bS = dw[i] * (1 - rF) * bSm, ersI = ers * wBest[i], omvI = omv * wOmv[i], pabI = pab * wPab[i], renI = ren * wBest[i];
        retired[i] = Math.min(S.btaTot[i], retired[i] + ersI);
        renovated[i] = Math.min(Math.max(0,S.btaTot[i]-retired[i]),renovated[i]+renI);
        cumAtemp[i] += (bF + bS + lok[i] + pabI + ersI) * P.atempNy; cumBta[i] += bF + bS + lok[i] + pabI + omvI;
        comp.bygg[yi][i] = ((bF * t.fF * tra + bS * t.fS + lok[i] * t.fL * tra + ersI * (S.bostAndel * t.fF + (1 - S.bostAndel) * t.fL) * tra) * ab + ersI * P.efRivning) / 1000;
        comp.anl[yi][i] = ((bF + bS + lok[i] + ersI) * P.grundKgBta + utv[i] * 1e4 * P.anlKgMark + dF*(rF*bFbh+(1-rF)*bSm)*P.fortAnlKgBta) * t.iAnl / 1000;
        comp.byggdel[yi][i] = (P.komponentAktiv==='ja'?P.antalByggdelar:0)*(P.byggdelDeso?(S.ids[i]===P.byggdelDeso?1:0):wBest[i])/1000*(P.bevaraByggdel==='nej' ? (y===P.arByteRef?P.efByteByggdel:0) : (y===P.arByteRef?P.efBevaraByggdel:0)+(y===P.arByteAlt?P.efByteByggdel:0));
        comp.omb[yi][i] = (omvI * P.efOmv + pabI * P.pabFaktor * t.fF * tra * ab + renI * P.efRenovering) / 1000;
        const d = P.perspektiv === 'A' ? S.A : S.B;
        const shift = P.byteBil2050/100*ramp(y), altPerVkm = P.belaggningBil*P.alternativGpkm/1e6;
        comp.mob[yi][i] = ((d.fuel[i] * t.fl + d.el[i] * t.kEl + d.fordon[i] * t.ip)*(1-shift) + d.vkm[i]*shift*altPerVkm) * t.tr;
        comp.energi[yi][i] = (S.kwhEl[i] * t.fk.el + S.kwhFv[i] * t.fk.fv) / 1000 * t.eff * Math.max(0,1-(S.btaTot[i]>0?(retired[i]+renovated[i]*P.renEnergiBesparing/100)/S.btaTot[i]:0));
        comp.nydrift[yi][i] = cumAtemp[i] * P.energiNy * t.mixNy / 1000;
        const vkm = (hhUtb[i] * P.bilFaktorUtb + hhBef[i] * P.bilFaktorBef) * S.cph[i] * S.km[i];
        if (P.perspektiv === 'B') comp.nymob[yi][i] = vkm * (epv(i, t)*(1-shift)+shift*altPerVkm);
        sVkm += vkm; pop[yi][i] = S.bef[i] + cumInv[i]; nyaInv[yi][i] = cumInv[i]; nyBta[yi][i] = cumBta[i];
        sB += comp.bygg[yi][i]; sO += comp.omb[yi][i]; sM += mark[i]; sA += comp.anl[yi][i]; sU += utv[i];
      }
      if (P.perspektiv === 'A') { const g = P.andelKmInomMalmo * sVkm / S.cityAvkm; for (let i = 0; i < n; i++) comp.nymob[yi][i] = comp.mob[yi][i] * g; }
      popForra = popY;
      stad.push({year: y, pop: popY, N, invSuff, bost, brutto, suffBta: brutto - btaBost - nyLok, btaBost, nyFbh, nySm: behovSm, nyLok, omv, pab, riv, ren, ers,
        dwNy, dwUtb, dwFort, dwOmv, dwPab, fullt, takOmv: onskOmv - omv > 1e-9 && takOmv - cumOmv <= 1e-6, takPab: onskPab - pab > 1e-9 && takPab - cumPab <= 1e-6,
        fF: t.fF * tra * ab, fS: t.fS * ab, fL: t.fL * tra * ab, efEl: t.fk.el, efFv: t.fk.fv, flotta: t.fl, iAnl: t.iAnl, byggdel: comp.byggdel[yi].reduce((a,b)=>a+b,0), bygg: sB, anl: sA, omb: sO, mark: sM, utvHa: sU, nyVkm: sVkm});
    });

    return {P, years, comp, pop, nyaInv, nyBta, stad, Cu, risk, trafikHh, typologi: ty, tra, ab,
      areas: areas.map(a => ({id: a.id, namn: a.namn, kategori: a.kategori, fokus: a.fokus, bostader: a.bostader, arbetsplatser: a.arbetsplatser, ha: a.ha, Au: a.Au,
        Cu: a.Cu, tagen: a.tagen, L: a.L, dw: a.dw, arb: Math.min(a.arbetsplatser, a.arb), f: a.f, mark: a.mark, trafik: a.trafik, poang: a.poang})),
      tak: {omv: takOmv, pab: takPab, cumOmv, cumPab}};
  }

  /* Lokaliseringsindikatorn: klimatpåverkan som en ny bostad skulle orsaka om den byggdes i DeSO:n, t CO2e 2025–2050.
       trafik = Σ år bilar per hushåll × km per bil × t per fordonskilometer (värd-DeSO:ns värden)
       bygg   = BTA per bostad × klimatfaktor år 2030 (blandningen av flerbostadshus och småhus)
       mark   = markanspråk per bostad × ohårdgjord andel i DeSO:n × förlust per hektar (förväntad förlust om läget i DeSO:n är okänt) */
  function perBostad(S, R, i) {
    const P = R.P, aF = P.andelFbh / 100, t = R.stad.find(r => r.year === 2030);
    const trafik = R.trafikHh[i] * P.bilFaktorBef, bygg = (aF * housing(P).fbh * t.fF + (1 - aF) * housing(P).smahus * t.fS) / 1000;
    const andel = S.kolYta[i] > 0 ? Math.min(1, S.Au[i] / S.kolYta[i]) : 0, mark = R.typologi.ha * andel * R.risk[i];
    return {trafik, bygg, mark, total: trafik + bygg + mark};
  }

  /* Värden för valt år ('ack' = summa 2025–2050) som en rad per DeSO, med statiska indikatorer. */
  function view(S, R, ar) {
    const n = S.n, sel = ar === 'ack' ? R.years.map((y, i) => [y, i]).filter(([y]) => y >= ACK[0] && y <= ACK[1]).map(x => x[1]) : [R.years.indexOf(Number(ar))];
    if (sel.some(i => i < 0)) throw new Error('Okänt år: ' + ar);
    const sist = sel[sel.length - 1], rows = [];
    for (let i = 0; i < n; i++) {
      const r = {id: S.ids[i], i, namn: S.namn[i], land_ha: S.landHa[i]};
      let tot = 0;
      for (const c of KOMP) { let v = 0; for (const yi of sel) v += R.comp[c][yi][i]; r[c] = v; tot += v; }
      r.total = tot; r.mob_tot = r.mob + r.nymob; r.energi_tot = r.energi + r.nydrift; r.ny_tot = r.bygg + r.anl; r.bygg_tot = r.bygg + r.anl + r.omb + r.byggdel;
      r.bef = R.pop[sist][i]; r.nya_inv = R.nyaInv[sist][i]; r.bta_ny = R.nyBta[sist][i];
      // statiska indikatorer
      r.kol_forrad = (S.markkolC[i] + S.bioC[i]) * C_TO_CO2;                      // t CO2e bundet i mark och vegetation
      r.kol_ha = S.Au[i] > 0 ? (S.markkolC[i] + S.bioC[i]) / S.Au[i] : null;      // t C per ha ohårdgjord mark
      r.ohardgjord = S.kolYta[i] > 0 ? 100 * S.Au[i] / S.kolYta[i] : null;        // %
      r.kol_risk = S.Au[i] > 0 ? R.risk[i] : null;                                // t CO2e per ha som bebyggs
      r.bil_hh = R.P.lokalaData[r.id]?.bilarPerHushall ?? (S.hh[i] > 0 ? S.bil[i] / S.hh[i] : null);
      r.kwh_m2 = S.atemp[i] > 0 ? ((R.P.lokalaData[r.id]?.kwhEl ?? S.kwhEl[i]) + (R.P.lokalaData[r.id]?.kwhFv ?? S.kwhFv[i])) / S.atemp[i] : null;
      r.pot_omv = S.btaLokal[i]; r.pot_pab = S.btaFbh[i];
      const pb = perBostad(S, R, i); r.per_bostad = pb.total; r.pb = pb;
      rows.push(r);
    }
    const city = {land_ha: 0, bef: 0, nya_inv: 0, bta_ny: 0, kol_forrad: 0, pot_omv: 0, pot_pab: 0};
    for (const k of [...KOMP, 'total', 'mob_tot', 'energi_tot', 'ny_tot', 'bygg_tot']) city[k] = 0;
    for (const r of rows) for (const k of Object.keys(city)) city[k] += r[k] || 0;
    return {rows, city, years: sel.length, ar};
  }
  /* Skillnaden mot referensen (hela behovet nybyggs): undvikna utsläpp från byggande, anläggning och mark per DeSO, t CO2e. */
  function undvikt(v, vRef) {
    return v.rows.map((r, i) => vRef.rows[i].bygg_tot + vRef.rows[i].mark - r.bygg_tot - r.mark);
  }

  /* Stadens värden per år. */
  function stadPerAr(R) {
    return R.years.map((y, yi) => { const o = {year: y}; let tot = 0; for (const c of KOMP) { o[c] = R.comp[c][yi].reduce((a, b) => a + b, 0); tot += o[c]; }
      o.total = tot; o.bef = R.pop[yi].reduce((a, b) => a + b, 0); for (const p of PERSPEKTIV_ID) o['p_' + p] = PERSPEKTIV[p].komp.reduce((s, c) => s + o[c], 0); return o; });
  }
  /* Summor per byggperiod (fram till 2030, 2035, 2040, 2045 och 2050): folkökning, BTA-behov, hur behovet möts och klimatpåverkan. */
  function perioder(R) {
    const ar = stadPerAr(R), F = ['N', 'invSuff', 'bost', 'brutto', 'suffBta', 'btaBost', 'nyFbh', 'nySm', 'nyLok', 'omv', 'pab', 'riv', 'ren', 'ers', 'dwNy', 'dwUtb', 'dwFort', 'dwOmv', 'dwPab', 'fullt', 'utvHa'];
    return PERIOD.map(([a, b]) => {
      const o = {fran: a, till: b, ar: b - a + 1}; for (const f of F) o[f] = 0; for (const c of [...KOMP, 'total']) o[c] = 0;
      R.stad.forEach((s, i) => { if (s.year < a || s.year > b) return; for (const f of F) o[f] += s[f]; for (const c of [...KOMP, 'total']) o[c] += ar[i][c]; });
      o.pop = R.stad.find(s => s.year === b).pop;
      o.nybyggd = o.nyFbh + o.nySm + o.nyLok + o.ers;                 // m² BTA som nybyggs
      o.behov = o.brutto + o.riv;                                      // m² BTA som behövs utan cirkulära åtgärder
      o.byggande = o.bygg + o.anl + o.omb + o.byggdel;                             // t CO2e för att möta behovet
      return o;
    });
  }

  /* Omräkning till funktionell enhet. Statiska indikatorer har egen enhet och räknas inte om. */
  const STATISKA = {kol_forrad: 't CO₂e bundet', kol_ha: 't C per ha ohårdgjord mark', ohardgjord: '% ohårdgjord mark', kol_risk: 't CO₂e per ha som bebyggs',
    bil_hh: 'bilar per hushåll', kwh_m2: 'kWh per m² Atemp och år', pot_omv: 'm² BTA lokaler', pot_pab: 'm² BTA flerbostadshus', per_bostad: 't CO₂e per ny bostad, 2025–2050',
    nya_inv: 'nya invånare sedan 2024', bta_ny: 'm² BTA tillkommen sedan 2024'};
  function metric(row, key, unit) {
    const v = row[key];
    if (v == null) return null;
    if (key in STATISKA) return v;
    if (unit === 't') return v;
    if (unit === 't_ha') return row.land_ha > 0 ? v / row.land_ha : null;
    if (unit === 'kg_ha') return row.land_ha > 0 ? v * 1000 / row.land_ha : null;
    if (unit === 't_inv') return row.bef > 0 ? v / row.bef : null;
    throw new Error('Okänd enhet');
  }

  return {VERSION, BAS, SLUT, AR, MIL, PERIOD, ACK, KOMP, NAMN, KORT, PERSPEKTIV, PERSPEKTIV_ID, BYGG, P75_PROXY, TAKTPERIOD, UTV, EL_ALT, BECCS, POP_STD, POP_NIVA,
    DEFAULTS, LIMITS, ENUMS, CIRK, CIRK_NIVA, STATISKA, C_TO_CO2,
    housing, circularComparison, circularAttribution, LOCAL_FIELDS, validateLocal, params, utanCirk, harCirk, prepare, compute, view, undvikt, stadPerAr, perioder, metric, perBostad,
    indexAr, faktorer, flottaIndex, bilprodIndex, byggFaktor, folkmangd, kolPerHa, typologi, ramp};
});
