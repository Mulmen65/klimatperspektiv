/* Klimatperspektiv – gränssnitt. Samma struktur och stil som Vägvis och Road2Zero-OP. */
(function () {
'use strict';
const M = window.Klimatperspektiv, $ = id => document.getElementById(id);
const esc = x => String(x ?? '').replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
const nf = (x, d = 0) => { if (x == null || !Number.isFinite(x)) return '–'; const t = new Intl.NumberFormat('sv-SE', {maximumFractionDigits: d, minimumFractionDigits: d}).format(x); return /^[−-]0([,.]0+)?$/.test(t) ? t.slice(1) : t; };
const sig = x => { if (x == null || !Number.isFinite(x)) return '–'; const a = Math.abs(x); if (a < 5e-4) return '0'; return nf(x, a >= 100 ? 0 : a >= 10 ? 1 : a >= 1 ? 2 : 3); };
const kt = x => nf(x / 1000, Math.abs(x) >= 1e5 ? 0 : 1);
const json = id => JSON.parse($(id).textContent);
const D = {deso: json('d-deso'), land: json('d-land'), grund: json('d-grund'), kol: json('d-kol'), utb: json('d-utb'), meta: json('d-meta')};
const S = M.prepare(D);
const STORE = 'klimatperspektiv-malmo-antaganden';
const store = {get() { try { return JSON.parse(localStorage.getItem(STORE) || 'null'); } catch (e) { return null; } },
  set(v) { try { localStorage.setItem(STORE, JSON.stringify(v)); } catch (e) { /* lagring ej tillgänglig */ } }};
let P = M.params(store.get() || {}), R, Rref, V = null, Vref = null;
function rakna() { R = M.compute(S, P); Rref = M.harCirk(P) ? M.compute(S, M.utanCirk(P)) : R; V = null; }
rakna();
/* Rader per DeSO för valt år, med undvikna utsläpp mot referensen (hela behovet nybyggs). */
function cur() {
  if (V) return V;
  V = M.view(S, R, P.ar); Vref = Rref === R ? V : M.view(S, Rref, P.ar);
  const u = M.undvikt(V, Vref); V.rows.forEach((r, i) => { r.undvikt = u[i]; }); V.city.undvikt = u.reduce((a, b) => a + b, 0);
  V.rows.forEach((r,i)=>{r.cirk_bidrag=-r.undvikt;r.undviket_bygg=Vref.rows[i].bygg_tot-r.bygg_tot;r.undviket_total=Vref.rows[i].total-r.total;});
  return V;
}

/* ---------- perspektiv, färger och nyckeltal ---------- */
const PF = {total: ['#167567', '#e3efe6', '#0d4a41'], mark: ['#5d9b57', '#e8f2df', '#2c5e2b'], ny: ['#c9982b', '#f8efd6', '#7d5a0e'],
  transport: ['#2a78d6', '#e1edfa', '#123f7c'], energi: ['#8a63c9', '#eee6f8', '#4b2b85'], cirk: ['#2f9c8a', '#dff1ec', '#125a4e']};
const KF = {byggdel:'#bc8c6b', mark: '#5d9b57', bygg: '#c9982b', anl: '#e6c777', omb: '#2f9c8a', mob: '#2a78d6', nymob: '#86b4ea', energi: '#8a63c9', nydrift: '#bda8e6'};
const STACK = ['mark', 'ny', 'transport', 'energi', '-anpassning', 'cirk', 'total'];   // ordningen i lagerstapeln
const pNamn = id => id === 'total' ? 'Alla perspektiv' : M.PERSPEKTIV[id].namn;
const pKomp = id => id === 'total' ? M.KOMP : M.PERSPEKTIV[id].komp;
const NYCKELTAL = {
  total: [['total', 'Alla perspektiv, summa']],
  mark: [['mark', 'Förändrad markanvändning'], ['kol_risk', 'Förlust om marken bebyggs'], ['kol_forrad', 'Kolförråd i mark och vegetation'], ['kol_ha', 'Kol per hektar ohårdgjord mark'], ['ohardgjord', 'Ohårdgjord andel']],
  ny: [['ny_tot', 'Nyexploatering, summa'], ['bygg', 'Nybyggnad (A1–A5) och rivning'], ['anl', 'Grundläggning, gator och ledningar'], ['per_bostad', 'Lokalisering · per ny bostad'], ['bta_ny', 'Tillkommen yta sedan 2024'], ['nya_inv', 'Nya invånare sedan 2024']],
  transport: [['mob_tot', 'Mobilitet, summa'], ['mob', 'Mobilitet i befintlig stad'], ['nymob', 'Nya invånares mobilitet'], ['bil_hh', 'Bilar per hushåll 2024']],
  energi: [['energi_tot', 'Energi, summa'], ['energi', 'Energi i befintliga byggnader'], ['nydrift', 'Nya byggnaders energi'], ['kwh_m2', 'Energianvändning per m² 2024']],
  cirk: [['undvikt', 'Undviket byggande och mark'], ['byggdel','Separata byggdelars faktiska utsläpp'], ['omb', 'Omvandling, påbyggnad och renovering'], ['bygg_tot', 'Allt byggande: nytt och cirkulärt'], ['pot_omv', 'Omvandlingspotential: lokalyta'], ['pot_pab', 'Påbyggnadspotential: flerbostadshus']]
};
const HUVUD = {total: 'total', mark: 'mark', ny: 'ny_tot', transport: 'mob_tot', energi: 'energi_tot', cirk: 'undvikt'};   // nyckeltal i små kartor och klimatkort
const TEXT = {
  total: 'Summan av faktiska utsläppskomponenter, inklusive separat byggdelspost när den används. Nybyggnad hör till Nyexploatering, medan omvandling, påbyggnad och renovering hör till Cirkularitet. Kontrollera även källornas avgränsning av laddel mot byggnadsel.',
  mark: 'Kol som lämnar mark och vegetation när ohårdgjord mark bebyggs, bokfört det år ytan tas i anspråk. Störst där utbyggnadsområden ligger på åker och grönytor.',
  kol_risk: 'Så mycket koldioxid som går förlorat om en hektar ohårdgjord mark i området bebyggs med den valda blandningen av hustyper. Oberoende av årsvalet.',
  kol_forrad: 'Kol bundet i mark (0–0,5 m), dött organiskt material och biomassa på ohårdgjord mark, uttryckt som koldioxid. Ett förråd, inte ett årligt utsläpp.',
  kol_ha: 'Kolförrådet per hektar ohårdgjord mark. Åkermark och parker med gamla träd har mest.',
  ohardgjord: 'Andel av landytan där SLU:s kolkarta har markkol, alltså mark som inte är bebyggd eller hårdgjord.',
  ny_tot: 'Nybyggnad, rivning och anläggning: allt som byggs nytt för att möta behovet av yta.',
  anl: 'Grundläggning av nya byggnader samt gator, ledningar och allmän plats i utbyggnadsområden. Förtätning antas använda den infrastruktur som redan finns.',
  bygg: 'Byggskedets klimatpåverkan (A1–A5) för nya bostäder och lokaler och för byggnader som ersätter rivna, bokförd det år byggnaden står klar. Rivningen ingår.',
  per_bostad: 'Klimatpåverkan som en ny bostad skulle orsaka om den byggdes här: de boendes bilresor 2025–2050, byggandet och förväntad kolförlust från marken. Oberoende av årsvalet.',
  bta_ny: 'Ny bostads- och lokalyta sedan 2024 enligt scenariot, inklusive omvandlad och påbyggd yta.',
  nya_inv: 'Nya invånare sedan 2024 enligt scenariot, i nya, omvandlade och påbyggda bostäder och i befintligt bestånd.',
  mob_tot: 'Trafiken i befintlig stad plus de nya invånarnas bilresor.',
  mob: 'Trafiken i befintlig stad enligt Vägvis: A = all trafik på vägarna i området, B = de boendes bilar. Livscykelperspektiv: avgaser, drivmedlens produktion och fordonens tillverkning.',
  nymob: 'De nya invånarnas bilar, med värdområdets bilinnehav och körsträcka. I perspektiv A fördelas trafiken över vägnätet i proportion till dagens trafik.',
  bil_hh: 'Personbilar i trafik per hushåll 2024 (SCB via Vägvis). Styr hur mycket nya hushåll i området antas köra.',
  energi_tot: 'El och fjärrvärme i befintliga och nya byggnader.',
  energi: 'El och fjärrvärme i befintliga byggnader ur energideklarationer och skattade byggnader, gånger årets emissionsfaktor.',
  nydrift: 'El och fjärrvärme i byggnader som tillkommit sedan 2024.',
  kwh_m2: 'Levererad energi per kvadratmeter Atemp i befintliga byggnader. Höga värden pekar på potential för energieffektivisering.',
  omb: 'Byggskedets klimatpåverkan för omvandling av lokaler till bostäder, påbyggnad och renovering i stället för rivning.',
  bygg_tot: 'Allt byggande som behövs för att möta behovet av yta: nybyggnad, rivning, anläggning, omvandling, påbyggnad och renovering.',
  undvikt: 'Skillnaden mot referensen där hela behovet nybyggs: byggande, anläggning och markanvändning. Noll så länge inga cirkulära åtgärder är valda.',
  pot_omv: 'Befintlig lokalyta (kontor, handel, service). Här fördelas omvandlingen till bostäder.',
  pot_pab: 'Befintlig yta i flerbostadshus. Här fördelas påbyggnaden.'
};
const UNITS = ['t', 't_ha', 'kg_ha', 't_inv'];
const isAck = () => P.ar === 'ack';
const yearLabel = y => y === 'ack' ? '2025–2050' : String(y);
const unitBase = u => isAck() ? ({t: 't CO₂e 2025–2050', t_ha: 't CO₂e per ha, 2025–2050', kg_ha: 'kg CO₂e per ha, 2025–2050', t_inv: 't CO₂e per invånare, 2025–2050'}[u])
  : ({t: 't CO₂e per år', t_ha: 't CO₂e per ha och år', kg_ha: 'kg CO₂e per ha och år', t_inv: 't CO₂e per invånare och år'}[u]);
const statisk = k => k in M.STATISKA;
const unitLabel = (k, u) => statisk(k) ? M.STATISKA[k] : unitBase(u);
const metricLabel = k => { for (const l of Object.values(NYCKELTAL)) for (const [a, b] of l) if (a === k) return b; return k; };
const mobLabel = () => P.perspektiv === 'A' ? 'A · Trafik inom området' : 'B · Hushållens bilar';
const scenLabel = () => M.harCirk(P) ? 'Cirkulära åtgärder valda' : 'Referens: hela behovet nybyggs';
const changed = () => P.elVal !== M.DEFAULTS.elVal || Object.keys(M.DEFAULTS).some(k => !['ar', 'perspektiv', 'efEl'].includes(k) && String(P[k]) !== String(M.params({elVal: P.elVal})[k]));

const st = {view: 'overview', persp: 'total', metric: {...HUVUD}, unit: 't', selected: null, osm: true, dev: true, sort: ['v', -1], filter: ''};
const HEAD = {
  overview: ['KLIMATPERSPEKTIV', 'Fem perspektiv på Malmös klimatpåverkan.<br><em>Samma karta, samma antaganden.</em>', 'Klimatpåverkan per DeSO 2024–2050 när staden växer: mark, nybyggnad, transporter, energi och cirkularitet. Välj perspektiv i lagerstapeln till vänster.'],
  map: ['KARTA & KLIMATKORT', 'Var uppstår klimatpåverkan?', 'Välj perspektiv, nyckeltal och enhet. Klicka på ett område för att se dess klimatkort med alla fem perspektiv.'],
  pop: ['BEFOLKNING & NYBYGGNATION', 'Hur många blir vi, och vad behöver byggas?', 'Ange folkmängden 2030–2050, typ av bebyggelse, klimatpåverkan per m² BTA och var det byggs. Resultatet räknas om direkt.'],
  cirk: ['CIRKULARITET', 'Kan behovet mötas utan att bygga nytt?', 'Stegmodell: minska behovet, omvandla, bygg på, renovera, återbruka. Jämförs med referensen där hela behovet nybyggs.'],
  parameters: ['ANTAGANDEN', 'Transport, energi och mark', 'Alla antaganden har ett förifyllt värde med källa. Ändringar sparas i den här webbläsaren.'],
  development: ['STADSUTVECKLING', 'Stadsutveckling och indata', 'Planeringsval, databehov, lokala uppgifter och känslighetsanalys.'],
  sources: ['KÄLLKONTROLL', 'Källornas stöd och begränsningar', 'Identitet, sakstöd och lokal tillämpbarhet kontrolleras separat.'],
  method: ['METOD & KÄLLOR', 'Så räknas resultatet', 'Systemgränser, formler, underlag, begränsningar och referenser.']
};
const post = (l, v) => '<span class="ctx-item"><small>' + l + '</small>' + v + '</span>';
const kontext = extra => '<div class="ctx-bar"><span class="ctx-title">Visas nu</span>' + post('Perspektiv', esc(pNamn(st.persp))) + post('År', esc(yearLabel(P.ar))) + (extra || '') + post('Mobilitet', esc(mobLabel())) + post('Byggande', esc(scenLabel())) + '</div>';
const notice = (html, cls = '') => '<div class="notice ' + cls + '">' + html + '</div>';
const flikar = () => '<div class="kp-flikar" role="group" aria-label="Perspektiv">' + STACK.filter(p => p[0] !== '-').map(p => '<button data-persp="' + p + '" class="' + (st.persp === p ? 'active' : '') + '"><i style="background:' + PF[p][0] + '"></i>' + esc(pNamn(p)) + '</button>').join('') + '</div>';

function renderChrome() {
  $('kp-stack').innerHTML = STACK.map(p => p === '-anpassning'
    ? '<button disabled title="Klimatanpassning ingår inte i modellen: riskbilden uttrycks inte i CO₂e"><i style="background:#c9706b"></i><span>Klimatanpassning<small>ingår inte</small></span></button>'
    : '<button data-persp="' + p + '" class="' + (st.persp === p ? 'active' : '') + '"><i style="background:' + PF[p][0] + '"></i><span>' + esc(pNamn(p)) + '</span></button>').join('');
  document.querySelectorAll('.model-switch button[data-model]').forEach(b => b.classList.toggle('active', b.dataset.model === P.perspektiv));
  document.querySelectorAll('nav .nav').forEach(b => b.classList.toggle('active', b.dataset.view === st.view));
  $('active-label').textContent = pNamn(st.persp).toUpperCase() + ' · ' + (P.perspektiv === 'A' ? 'A' : 'B');
  $('year-switch').innerHTML = [...M.AR, 'ack'].map(y => '<button data-year="' + y + '" class="' + (String(P.ar) === String(y) ? 'active' : '') + '">' + (y === 'ack' ? 'Σ 2025–50' : y) + '</button>').join('');
  const ch = changed(); $('data-status').textContent = ch ? 'Egna antaganden' : 'Grundantaganden'; $('data-status').className = 'pill' + (ch ? ' amber' : '');
  const [eb, t, d] = HEAD[st.view]; $('eyebrow').textContent = eb; $('page-title').innerHTML = t; $('page-description').textContent = d;
  $('primary-action').style.display = st.view === 'map' ? 'none' : '';
  $('scope-footer').textContent = ' · mobilitet: ' + mobLabel() + ' · el: ' + M.EL_ALT[P.elVal].namn + ' · folkmängd 2050: ' + nf(P.pop2050);
  $('kp-version').textContent = M.VERSION;
}
function setP(patch) { const next=M.params({...P,...patch}); M.compute(S,next); P=next; rakna(); store.set(P); renderChrome(); render(); }

/* ---------- diagram (SVG) ---------- */
function niceStep(raw) { if (!(raw > 0)) return 1; const p = Math.pow(10, Math.floor(Math.log10(raw))), f = raw / p; return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10) * p; }
/* Staplade staplar. kat: [{etikett, staplar: [{namn, v: {nyckel: värde}}], vald, attr}], serier: [[nyckel, namn, färg]]. */
function staplar(kat, serier, o = {}) {
  const W = 640, H = o.h || 250, L = 46, Rm = 8, T = 12, B = 34, div = o.div || 1, dec = o.dec ?? 0;
  const tot = s => serier.reduce((a, [k]) => a + Math.max(0, s.v[k] || 0), 0) / div;
  const max = Math.max(1e-9, ...kat.flatMap(c => c.staplar.map(tot))), step = niceStep(max / 4), top = Math.ceil(max / step) * step;
  const Y = v => T + (H - T - B) * (1 - v / top), bw = (W - L - Rm) / kat.length;
  let h = '<svg viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + esc(o.aria || 'Stapeldiagram') + '">';
  for (let v = 0; v <= top + 1e-9; v += step) h += '<line class="grid" x1="' + L + '" x2="' + (W - Rm) + '" y1="' + Y(v) + '" y2="' + Y(v) + '"/><text x="' + (L - 6) + '" y="' + (Y(v) + 3.5) + '" text-anchor="end">' + nf(v, step < 1 ? 1 : 0) + '</text>';
  kat.forEach((c, i) => {
    const n = c.staplar.length, w = Math.min(54, bw * 0.78 / n), x0 = L + bw * i + (bw - w * n - 4 * (n - 1)) / 2;
    c.staplar.forEach((s, q) => {
      let acc = 0; const x = x0 + q * (w + 4);
      for (const [k, namn, farg] of serier) { const v = Math.max(0, s.v[k] || 0) / div; if (!(v > 0)) continue;
        h += '<rect' + (c.attr ? ' class="klick" ' + c.attr : '') + ' x="' + x.toFixed(1) + '" y="' + Y(acc + v).toFixed(1) + '" width="' + w.toFixed(1) + '" height="' + Math.max(0.5, Y(acc) - Y(acc + v)).toFixed(1) + '" fill="' + farg + '"' + (s.matt ? ' opacity=".45"' : '') + '><title>' + esc(c.etikett + (s.namn ? ' · ' + s.namn : '') + ' · ' + namn + ': ' + nf(v, dec) + ' ' + (o.enhet || '')) + '</title></rect>'; acc += v; }
      if (o.summa !== false) h += '<text x="' + (x + w / 2).toFixed(1) + '" y="' + (Y(acc) - 4).toFixed(1) + '" text-anchor="middle"' + (c.vald ? ' class="vald"' : '') + '>' + nf(acc, dec) + '</text>';
      if (s.namn && n > 1) h += '<text x="' + (x + w / 2).toFixed(1) + '" y="' + (H - 20) + '" text-anchor="middle" style="font-size:9px">' + esc(s.namn) + '</text>';
    });
    h += '<text class="x' + (c.vald ? ' vald' : '') + '" x="' + (L + bw * (i + .5)).toFixed(1) + '" y="' + (H - 6) + '" text-anchor="middle">' + esc(c.etikett) + '</text>';
  });
  return '<div class="kp-chart">' + h + '</svg></div><div class="chart-legend">' + serier.map(([k, namn, farg]) => '<span><i style="background:' + farg + '"></i>' + esc(namn) + '</span>').join('') + (o.legendExtra || '') + '</div>';
}

/* ---------- kartfärger ---------- */
const hex = c => [1, 3, 5].map(i => parseInt(c.slice(i, i + 2), 16));
function ramp(p, t) { const a = hex(PF[p][1]), b = hex(PF[p][2]); return 'rgb(' + a.map((x, i) => Math.round(x + (b[i] - x) * t)).join(',') + ')'; }
function classes(vals) {
  const v = vals.filter(x => x != null && Number.isFinite(x) && x !== 0).sort((a, b) => a - b); if (!v.length) return [];
  const q = k => v[Math.min(v.length - 1, Math.floor(k * v.length))], br = [v[0], q(.2), q(.4), q(.6), q(.8), v[v.length - 1]];
  return br.filter((b, i) => i === 0 || b > br[i - 1]);
}
function colorFor(x, br, p) { if (x == null || !Number.isFinite(x) || x===0 || !br.length) return '#e3e8e4'; if(x<0)return '#c77869'; let k = 0; while (k < br.length - 2 && x > br[k + 1]) k++; return ramp(p, (k + .5) / Math.max(1, br.length - 1)); }

/* ---------- små kartor ---------- */
const MINI = (() => {
  let x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9;
  for (const f of D.land.features) for (const poly of (f.geometry.type === 'Polygon' ? [f.geometry.coordinates] : f.geometry.coordinates)) for (const [x, y] of poly[0]) { x0 = Math.min(x0, x); x1 = Math.max(x1, x); y0 = Math.min(y0, y); y1 = Math.max(y1, y); }
  const kx = Math.cos((y0 + y1) / 2 * Math.PI / 180), W = 300, s = W / ((x1 - x0) * kx), H = Math.round((y1 - y0) * s);
  const path = (g, steg) => (g.type === 'Polygon' ? [g.coordinates] : g.coordinates).map(p => p.map(r => { const n = r.length, k = n > 60 ? steg : 1; let d = '';
    for (let i = 0; i < n; i += k) d += (i ? 'L' : 'M') + ((r[i][0] - x0) * kx * s).toFixed(1) + ' ' + ((y1 - r[i][1]) * s).toFixed(1); return d + 'Z'; }).join('')).join('');
  return {W, H, land: D.land.features.map(f => path(f.geometry, 2)).join(''), deso: D.deso.features.map(f => path(f.geometry, 3))};
})();
function miniKarta(p, rows) {
  const k = HUVUD[p], vals = rows.map(r => M.metric(r, k, st.unit)), br = classes(vals), id = 'kp-klipp-' + p;
  return '<svg viewBox="0 0 ' + MINI.W + ' ' + MINI.H + '" aria-hidden="true"><defs><clipPath id="' + id + '"><path d="' + MINI.land + '" clip-rule="evenodd"/></clipPath></defs><path d="' + MINI.land + '" fill="#e3e8e4"/><g clip-path="url(#' + id + ')">' +
    MINI.deso.map((d, i) => '<path d="' + d + '" fill="' + colorFor(vals[i], br, p) + '" stroke="#fff" stroke-width=".25"/>').join('') + '</g></svg>';
}

/* ---------- 01 Översikt ---------- */
function behovTabell(kort) {
  const pr = M.perioder(R), ref = Rref === R ? null : M.perioder(Rref), m = x => nf(x / 1000, 0);
  const rad = (namn, f, cls, d) => '<tr' + (cls ? ' class="' + cls + '"' : '') + '><td>' + namn + '</td>' + pr.map((p, i) => '<td>' + f(p, ref && ref[i]) + '</td>').join('') + '<td>' + d + '</td></tr>';
  const sum = k => pr.reduce((s, p) => s + p[k], 0), lokInv = P.arbPerInv * P.btaArb + P.skolBtaPerInv;
  let h = '<div class="table-wrap calc-full"><table class="kp-tab"><thead><tr><th>Fram till</th>' + pr.map(p => '<th>' + p.till + '<br><small>' + p.fran + '–' + p.till + '</small></th>').join('') + '<th>Summa<br><small>2025–2050</small></th></tr></thead><tbody>';
  h += rad('Folkmängd vid periodens slut', p => nf(p.pop), '', '–') + rad('Nya invånare', p => nf(p.N), '', nf(sum('N')));
  h += rad('Behov av yta, 1 000 m² BTA', p => m(p.behov), 'sum', m(sum('behov')));
  if (!kort) h += rad('bostäder', p => m(p.brutto - p.N * lokInv), 'del', m(sum('brutto') - sum('N') * lokInv)) + rad('lokaler, skola och förskola', p => m(p.N * lokInv), 'del', m(sum('N') * lokInv)) + rad('ersättning för rivna byggnader', p => m(p.riv), 'del', m(sum('riv')));
  h += rad('Möts utan att bygga nytt, 1 000 m² BTA', p => m(p.suffBta + p.omv + p.pab + p.ren), '', m(sum('suffBta') + sum('omv') + sum('pab') + sum('ren')));
  if (!kort) h += rad('minskat behov (sufficiency)', p => m(p.suffBta), 'del', m(sum('suffBta'))) + rad('omvandling av lokaler', p => m(p.omv), 'del', m(sum('omv'))) + rad('påbyggnad', p => m(p.pab), 'del', m(sum('pab'))) + rad('renovering i stället för rivning', p => m(p.ren), 'del', m(sum('ren')));
  h += rad('Nybyggs, 1 000 m² BTA', p => m(p.nybyggd), '', m(sum('nybyggd')));
  h += rad('Byggandets klimatpåverkan, kt CO₂e', p => kt(p.byggande), 'sum', kt(sum('byggande')));
  if (!kort) h += rad('nybyggnad och rivning', p => kt(p.bygg), 'del', kt(sum('bygg'))) + rad('grundläggning, gator och ledningar', p => kt(p.anl), 'del', kt(sum('anl'))) + rad('omvandling, påbyggnad och renovering', p => kt(p.omb), 'del', kt(sum('omb')));
  if (ref) h += rad('referens: hela behovet nybyggs', (p, r) => kt(r.byggande), 'del', kt(ref.reduce((s, p) => s + p.byggande, 0)));
  h += rad('per m² behövd yta, kg CO₂e', p => nf(p.behov > 0 ? p.byggande * 1000 / p.behov : null, 0), 'del', nf(sum('byggande') * 1000 / Math.max(1, sum('behov')), 0));
  h += rad('Förändrad markanvändning, kt CO₂e', p => kt(p.mark), '', kt(sum('mark')));
  return h + '</tbody></table></div>';
}
function overview() { if(st.persp==='cirk')return kontext()+window.KPCircular.report(P,S,R,Rref)+window.KPCircular.area(P)+'<button data-view="cirk" class="primary">Alla cirkulära åtgärder och byggdelar</button>';
  const v = cur(), c = v.city, ar = M.stadPerAr(R), bas = ar[0], p = st.persp, komp = pKomp(p), ack = isAck(), nAr = v.years;
  const val = komp.reduce((s, k) => s + c[k], 0), valBas = komp.reduce((s, k) => s + bas[k], 0), delta = !ack && P.ar !== M.BAS && valBas > 0 ? (val - valBas) / valBas : null;
  const perP = M.PERSPEKTIV_ID.map(id => [id, M.PERSPEKTIV[id].komp.reduce((s, k) => s + c[k], 0)]), maxP = Math.max(1, ...perP.map(x => x[1]));
  let h = kontext() + notice('<strong>Screening för översiktlig planering.</strong> Modellen visar storleksordningar och skillnader mellan platser, inte officiell utsläppsstatistik. Nuläget (2024) bygger på energideklarationer, Vägvis och SLU:s kolkartor. Åren 2030–2050 är en framskrivning med uttryckliga antaganden om folkmängd, bebyggelse och emissionsfaktorer, som du kan ändra.', 'info');
  let fyra;
  if (p === 'mark') fyra = ['Kolförråd i mark och vegetation', nf(c.kol_forrad / 1e6, 2), 'Mt CO₂e', 'bundet i ohårdgjord mark i Malmö. ' + nf(R.areas.reduce((s, a) => s + a.mark, 0) / 1000, 1) + ' kt lämnar marken 2025–2050 i scenariot.'];
  else if (p === 'ny') fyra = ['Tillkommen yta sedan 2024', nf(c.bta_ny / 1e6, 2), 'Mm² BTA', nf(c.nya_inv) + ' nya invånare ' + (ack ? 'till 2050' : 'till ' + P.ar) + '.'];
  else if (p === 'transport') fyra = ['Nya invånares andel', nf(100 * c.nymob / Math.max(1, c.mob_tot), 1), '%', 'av mobilitetens klimatpåverkan ' + yearLabel(P.ar) + '.'];
  else if (p === 'energi') fyra = ['Nya byggnaders andel', nf(100 * c.nydrift / Math.max(1, c.energi_tot), 1), '%', 'av energins klimatpåverkan ' + yearLabel(P.ar) + '.'];
  else if (p === 'cirk') fyra = ['Undvikna utsläpp mot referensen', kt(c.undvikt), 'kt CO₂e', M.harCirk(P) ? 'byggande och mark, jämfört med att hela behovet nybyggs.' : 'Inga cirkulära åtgärder är valda. Välj dem under Cirkularitet.'];
  else fyra = ['Folkmängd', nf(c.bef), 'invånare', nf(c.nya_inv) + ' fler än 2024 (' + nf(S.bef0) + ').'];
  h += '<section class="kpis four"><article class="card kpi-main"><div class="kpi-label">' + esc(pNamn(p)) + ' · ' + yearLabel(P.ar) + '</div><div class="kpi-value">' + kt(val) + ' <span class="unit">kt CO₂e' + (ack ? '' : ' per år') + '</span></div><div class="kpi-foot">' + esc(p === 'total' ? 'Mark, nybyggnad, transporter, energi och cirkularitet' : komp.map(k => M.NAMN[k]).join(' · ')) +
    (delta != null ? ' · <span class="' + (delta > 0 ? 'delta-up' : 'delta-down') + '">' + (delta > 0 ? '+' : '') + nf(delta * 100, 1) + ' % mot 2024</span>' : '') + '</div></article>' +
    '<article class="card"><div class="kpi-label">Per invånare</div><div class="kpi-value">' + nf(val / c.bef / nAr, 2) + ' <span class="unit">t CO₂e/år</span></div><div class="kpi-foot">' + nf(c.bef) + ' invånare' + (ack ? ' (2050). Medel över 26 år.' : '') + '</div></article>' +
    '<article class="card"><div class="kpi-label">Per hektar</div><div class="kpi-value">' + nf(val / c.land_ha / nAr, 1) + ' <span class="unit">t CO₂e/ha·år</span></div><div class="kpi-foot">' + nf(c.land_ha) + ' ha land, havsytor ej medräknade</div></article>' +
    '<article class="card"><div class="kpi-label">' + fyra[0] + '</div><div class="kpi-value">' + fyra[1] + ' <span class="unit">' + fyra[2] + '</span></div><div class="kpi-foot">' + fyra[3] + '</div></article></section>';
  h += '<section class="grid2"><article class="card"><h2>Perspektiven · ' + yearLabel(P.ar) + '</h2><p class="card-sub">' + (ack ? 'Summa 2025–2050, kt CO₂e.' : 'kt CO₂e under kalenderåret.') + ' Hela Malmö. Klicka på en rad för att välja perspektiv.</p>' +
    perP.map(([id, x]) => '<button class="kp-rad' + (p === id ? ' active' : '') + '" data-persp="' + id + '"><span class="lbl"><i style="background:' + PF[id][0] + '"></i>' + esc(id==='cirk'?'Cirkulära insatser (faktiska utsläpp)':pNamn(id)) + '</span><span class="track">' + M.PERSPEKTIV[id].komp.map(k => '<span style="width:' + (100 * c[k] / maxP).toFixed(2) + '%;background:' + KF[k] + '" title="' + esc(M.NAMN[k]) + ': ' + kt(c[k]) + ' kt"></span>').join('') + '</span><b>' + kt(x) + ' kt</b></button>').join('') +
    '<div class="component-total"><span>Faktisk summa (cirkulära insatser som utsläpp, besparing separat)</span><span>' + kt(c.total) + ' kt CO₂e' + (ack ? '' : ' per år') + '</span></div>' +
    '<p class="small">Cirkularitetens undvikna utsläpp visas separat i dess kort och dras inte av igen från summan.</p><p class="small">' + esc(p === 'total' ? 'Perspektiven läses var för sig; summan visar storleksordningar. Klimatanpassning ingår inte, eftersom riskbilden inte uttrycks i CO₂e.' : 'Kärnfråga: ' + M.PERSPEKTIV[p].fraga) + '</p></article>' +
    '<article class="card"><h2>Utveckling 2024–2050 · ' + esc(pNamn(p)) + '</h2><p class="card-sub">Hela Malmö, kt CO₂e per år. Klicka på en stapel för att välja år.</p>' +
    staplar(M.AR.map(y => ({etikett: String(y), vald: P.ar === y, attr: 'data-year="' + y + '"', staplar: [{v: ar.find(r => r.year === y)}]})), komp.map(k => [k, M.KORT[k], KF[k]]), {div: 1000, dec: 0, enhet: 'kt CO₂e', aria: 'Klimatpåverkan per år och komponent'}) + '</article></section>';
  h += '<article class="card"><h2>Fem kartlager · ' + yearLabel(P.ar) + '</h2><p class="card-sub">' + esc(unitBase(st.unit)) + ' per DeSO. Mörkare färg är högre värde; varje karta har sin egen skala i fem lika stora grupper. Klicka på en karta för att öppna den.</p><div class="kp-mini">' +
    M.PERSPEKTIV_ID.map(id => '<button data-persp="' + id + '" data-oppna="1" class="' + (p === id ? 'active' : '') + '"><h3><i style="background:' + PF[id][0] + '"></i>' + esc(M.PERSPEKTIV[id].namn) + '</h3><small>' + esc(metricLabel(HUVUD[id])) + '</small>' + miniKarta(id, v.rows) + '</button>').join('') + '</div>' +
    '<p class="kp-legend-not">Grått: noll eller inget värde. Rött i cirkularitetslagret: ökad påverkan mot referensen. Markanvändningen syns bara där ohårdgjord mark tas i anspråk. Byt enhet under Karta & klimatkort.</p></article>';
  h += '<article class="card"><h2>Behovet av yta och hur det möts</h2><p class="card-sub">Folkmängden styr behovet av bostäder och lokaler. Summor per period fram till 2030, 2035, 2040, 2045 och 2050.</p>' + behovTabell(true) +
    '<div class="button-row" style="margin-top:16px"><button class="secondary" data-view="pop">Ändra folkmängd och bebyggelse →</button><button class="secondary" data-view="cirk">Pröva cirkulära åtgärder →</button><button class="secondary" data-view="map">Utforska DeSO på kartan →</button></div></article>';
  return h;
}

/* ---------- 02 Karta & klimatkort ---------- */
let map = null, layers = {}, devLayer = null;
const SEE = .68, OPAQUE = .95;
const curMetric = () => st.metric[st.persp];
function mapView() {
  const k = curMetric(), opts = NYCKELTAL[st.persp].map(([a, b]) => '<option value="' + a + '"' + (k === a ? ' selected' : '') + '>' + esc(b) + '</option>').join('');
  const units = UNITS.map(u => '<option value="' + u + '"' + (st.unit === u ? ' selected' : '') + '>' + esc(unitBase(u)) + '</option>').join('');
  const tom = !cur().rows.some(r => Math.abs(M.metric(r, k, st.unit)||0) > 0);
  const varfor = !tom ? '' : '<br><b>Alla områden har värdet noll.</b> ' + (P.ar === M.BAS ? 'Nuläget 2024 innehåller inget byggande och inga nya invånare. Välj ett senare år uppe till höger.'
    : ['omb', 'undvikt'].includes(k) && !M.harCirk(P) ? 'Inga cirkulära åtgärder är valda. Välj dem under Cirkularitet.' : 'Ändra antagandena för att se ett utfall.');
  return kontext(post('Nyckeltal', esc(metricLabel(k)))) + '<article class="card">' + flikar() + '<div class="map-toolbar2"><label class="inline">Nyckeltal <select id="metric">' + opts + '</select></label><label class="inline">Enhet <select id="unit"' + (statisk(k) ? ' disabled title="Nyckeltalet har en egen enhet"' : '') + '>' + units + '</select></label><span class="pill">' + esc(unitLabel(k, st.unit)) + (statisk(k) ? '' : ' · ' + yearLabel(P.ar)) + '</span></div>' +
    '<div class="map-checks"><label><input type="checkbox" id="map-osm"' + (st.osm ? ' checked' : '') + '> OpenStreetMap</label><label><input type="checkbox" id="map-dev"' + (st.dev ? ' checked' : '') + '> Utbyggnadsområden ÖP 2023</label><button class="map-fit secondary small-btn" id="map-fit">Hela kommunen</button></div>' +
    '<p class="map-what"><b>Kartan visar:</b> ' + esc(metricLabel(k)) + ' · ' + esc(unitLabel(k, st.unit)) + '. ' + esc(TEXT[k] || '') + varfor + '</p>' +
    '<div class="map-layout"><div><div class="map-surface" id="map-surface"></div><p class="small" id="map-status"></p></div><aside class="area-detail kp-kort" id="area-detail"></aside></div></article>' +
    '<article class="card"><div class="row wrap"><div><h2>Alla DeSO</h2><p class="card-sub">' + esc(unitBase(st.unit)) + ' · ' + yearLabel(P.ar) + '. Klicka på en rad för att visa området och på en kolumnrubrik för att sortera.</p></div><input class="input" id="table-filter" placeholder="Sök DeSO-kod eller område" value="' + esc(st.filter) + '" style="max-width:320px"></div><div class="table-wrap area-table" id="deso-table"></div></article>';
}
const polyPath = (g, project) => (g.type === 'Polygon' ? [g.coordinates] : g.coordinates).map(p => p.map(r => r.map((x, i) => (i ? 'L' : 'M') + project(x).join(',')).join('') + 'Z').join('')).join('');
function intervall(r, k) { if(Object.keys(P.lokalaData).length || P.byteBil2050>0 || P.renEnergiBesparing>0 || P.rivTakt>0 || P.effektivisering2050!==0)return null;   // 95 %-intervall där underlaget har ett: energi i befintliga byggnader och mobilitet i befintlig stad
  if (k === 'energi') return [r.energi * S.eLo[r.i], r.energi * S.eHi[r.i]];
  if (k === 'mob') { const d = P.perspektiv === 'A' ? S.A : S.B; return [r.mob * d.lo[r.i], r.mob * d.hi[r.i]]; }
  return null;
}
function drawMap() {
  const v = cur(), k = curMetric(), p = st.persp, vals = v.rows.map(r => M.metric(r, k, st.unit)), br = classes(vals), L = window.L, land = D.land;
  if (map) { map.remove(); map = null; } layers = {};
  map = L.map('map-surface', {scrollWheelZoom: false, zoomSnap: .25, attributionControl: false});
  const LandSVG = L.SVG.extend({
    _initContainer() { L.SVG.prototype._initContainer.call(this); const ns = 'http://www.w3.org/2000/svg', defs = document.createElementNS(ns, 'defs'); this._landClip = document.createElementNS(ns, 'clipPath'); this._clipID = 'kp-land-' + L.Util.stamp(this); this._landClip.setAttribute('id', this._clipID); this._landClip.setAttribute('clipPathUnits', 'userSpaceOnUse'); defs.appendChild(this._landClip); this._container.appendChild(defs); this._rootGroup.setAttribute('clip-path', 'url(#' + this._clipID + ')'); },
    _update() { L.SVG.prototype._update.call(this); if (!this._map || !this._landClip) return; const pr = x => { const a = this._map.latLngToLayerPoint([x[1], x[0]]); return [a.x, a.y]; }; this._landClip.innerHTML = land.features.map(f => '<path clip-rule="evenodd" fill-rule="evenodd" d="' + polyPath(f.geometry, pr) + '"/>').join(''); }
  });
  const layer = L.geoJSON(D.deso, {renderer: new LandSVG({padding: .5}), style: f => ({color: '#ffffff', weight: .7, opacity: .95, fillColor: colorFor(vals[S.index[f.properties.id]], br, p), fillOpacity: st.osm ? SEE : OPAQUE}),
    onEachFeature(f, l) {
      const id = f.properties.id, i = S.index[id]; layers[id] = l;
      l.bindTooltip(() => { const iv = st.unit === 't' ? intervall(v.rows[i], k) : null; return '<b>' + esc(id) + '</b> · ' + esc(S.namn[i]) + '<br>' + sig(vals[i]) + ' ' + esc(unitLabel(k, st.unit)) + (iv ? '<br><small>95 %: ' + sig(iv[0]) + '–' + sig(iv[1]) + '</small>' : ''); }, {sticky: true, className: 'map-tip'});
      l.on('click', () => selectArea(id, false));
      l.on('mouseover', () => { if (id !== st.selected) l.setStyle({weight: 2.2, color: '#0b463a'}); });
      l.on('mouseout', () => { if (id !== st.selected) l.setStyle({weight: .7, color: '#ffffff'}); });
    }}).addTo(map);
  const omr = Object.fromEntries(R.areas.map(a => [a.id, a]));
  devLayer = L.geoJSON({type: 'FeatureCollection', features: D.utb.omraden.map(a => ({type: 'Feature', properties: a, geometry: a.geometry}))}, {
    style: f => ({color: '#a76019', weight: 2.2, opacity: .95, fill: true, fillOpacity: 0, dashArray: f.properties.fokus === 2 ? '6 5' : null}),
    onEachFeature(f, l) { const a = f.properties, r = omr[a.id];
      l.bindTooltip('<b>' + esc(a.namn) + '</b><br>' + esc(a.kategori) + ' · Fokus ' + a.fokus + ' · ' + nf(a.ha, 1) + ' ha<br>Kapacitet: ' + nf(a.bostader) + ' bostäder · ' + nf(a.arbetsplatser) + ' arbetsplatser<br>Byggt 2050 i scenariot: ' + nf(100 * r.f) + ' % · mark ' + nf(r.mark / 1000, 1) + ' kt CO₂e', {sticky: true, className: 'map-tip dev-tip'}); }
  });
  if (st.dev) devLayer.addTo(map);
  const lc = L.control({position: 'bottomright'});
  lc.onAdd = () => { const d = L.DomUtil.create('div', 'map-legend'), n = br.length - 1;
    let h = '<b>' + esc(metricLabel(k)) + '</b><small style="margin:0 0 5px">' + esc(unitLabel(k, st.unit)) + '</small>';
    for (let q = 0; q < n; q++) h += '<span><i style="background:' + colorFor((br[q]+br[q+1])/2,br,p) + ';width:14px;height:10px;display:inline-block;border-radius:2px"></i>' + sig(br[q]) + '–' + sig(br[q + 1]) + '</span>';
    d.innerHTML = h + '<span><i class="nodata" style="background:#e3e8e4;width:14px;height:10px;display:inline-block;border-radius:2px;border:1px solid #b9c3be"></i>0 eller inget värde</span><small>Fem lika stora grupper av DeSO</small>'; L.DomEvent.disableClickPropagation(d); return d; };
  lc.addTo(map);
  const bounds = L.geoJSON(land).getBounds(); map.fitBounds(bounds, {padding: [12, 12]});
  const tiles = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {maxZoom: 19, referrerPolicy: 'strict-origin-when-cross-origin'});
  const local = location.protocol === 'file:';
  function osm() {
    if (local) { $('map-osm').checked = false; $('map-osm').disabled = true; layer.setStyle({fillOpacity: OPAQUE}); $('map-status').textContent = 'Offlinekarta. Bakgrundskartan visas när appen körs via Streamlit. Beräkningen fungerar ändå.'; return; }
    if (st.osm) { tiles.addTo(map); tiles.bringToBack(); layer.setStyle({fillOpacity: SEE}); $('map-surface').classList.add('osm-on'); $('map-status').textContent = 'OpenStreetMap · bakgrundskartan kräver internet. Havsytor är bortklippta i visningen; beräkningen använder SCB:s DeSO-gränser.'; }
    else { map.removeLayer(tiles); layer.setStyle({fillOpacity: OPAQUE}); $('map-surface').classList.remove('osm-on'); $('map-status').textContent = 'Bakgrund avstängd · områdeskartan fungerar utan internet.'; }
  }
  let fails = 0; tiles.on('tileerror', () => { if (++fails > 2) $('map-status').textContent = 'Bakgrundskartan kunde inte hämtas. Områdeskartan och beräkningen fungerar ändå.'; });
  $('map-osm').onchange = e => { st.osm = e.target.checked; osm(); }; osm();
  $('map-dev').onchange = e => { st.dev = e.target.checked; if (st.dev) devLayer.addTo(map); else map.removeLayer(devLayer); };
  $('map-fit').onclick = () => map.fitBounds(bounds, {padding: [12, 12]});
  L.control.attribution({position: 'bottomleft', prefix: '<a href="https://leafletjs.com" target="_blank" rel="noopener">Leaflet</a>'}).addTo(map).addAttribution('© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> · Områden: SCB DeSO 2025 · Utbyggnadsområden: Malmö stad ÖP 2023');
  setTimeout(() => map && map.invalidateSize(), 60);
  if (st.selected) highlight(st.selected);
}
function highlight(id) { for (const [k, l] of Object.entries(layers)) l.setStyle(k === id ? {weight: 3, color: '#0b463a'} : {weight: .7, color: '#ffffff'}); if (layers[id]) layers[id].bringToFront(); }
function selectArea(id, zoom) { st.selected = id; highlight(id); detail(); table(); if (zoom && map && layers[id]) map.fitBounds(layers[id].getBounds(), {padding: [80, 80], maxZoom: 14}); }
const median = a => { const v = a.filter(x => x != null && Number.isFinite(x)).sort((x, y) => x - y); return v.length ? v[Math.floor(v.length / 2)] : 0; };
const kvantil = (a, q) => { const v = a.filter(x => x != null && Number.isFinite(x)).sort((x, y) => x - y); return v.length ? v[Math.min(v.length - 1, Math.floor(q * v.length))] : 0; };
/* Planeringssignaler: vad kartan betyder för fortsatt planering i området. Gränserna är modellval. */
function signaler(r, rows) {
  const ut = [], medT = median(rows.map(x => x.pb.trafik)), medR = median(rows.map(x => x.kol_risk)), omr = R.areas.filter(a => S.areas.find(x => x.id === a.id).delar.some(d => d.i === r.i));
  if (r.pb.trafik > 1.25 * medT) ut.push(['T', 'Bilresorna per ny bostad ligger ' + nf(100 * (r.pb.trafik / medT - 1)) + ' % över medianen. Pröva kollektivtrafik, service och mobilitetsåtgärder innan området byggs ut.']);
  else if (r.pb.trafik < 0.75 * medT) ut.push(['+', 'Bilresorna per ny bostad ligger ' + nf(100 * (1 - r.pb.trafik / medT)) + ' % under medianen. Läget ger förutsättningar för låga transportutsläpp.']);
  if (r.ohardgjord > 30 && r.kol_risk > medR) ut.push(['M', 'Mycket ohårdgjord mark med stort kolförråd: ' + nf(r.kol_risk) + ' t CO₂e går förlorat per hektar som bebyggs. Koncentrera markanspråket och peka ut ytor att bevara.']);
  for (const a of omr) ut.push(['U', 'Utbyggnadsområde i ÖP 2023: ' + a.namn + ' (' + nf(a.bostader) + ' bostäder, ' + nf(a.arbetsplatser) + ' arbetsplatser). I scenariot byggs ' + nf(100 * a.f) + ' % till 2050 och ' + nf(a.mark / 1000, 1) + ' kt CO₂e lämnar marken.']);
  if (r.pot_omv > kvantil(rows.map(x => x.pot_omv), .75)) ut.push(['C', 'Stor befintlig lokalyta (' + nf(r.pot_omv / 1000) + ' 000 m² BTA). Pröva omvandling och ändrad användning före nybyggnad.']);
  if (r.kwh_m2 > kvantil(rows.map(x => x.kwh_m2), .75)) ut.push(['E', 'Hög energianvändning per m² (' + nf(r.kwh_m2) + ' kWh). Potential för energieffektivisering i befintligt bestånd.']);
  return ut;
}
function detail() {
  const el = $('area-detail'); if (!el) return;
  const v = cur(), k = curMetric();
  if (!st.selected) { el.innerHTML = '<div class="ad-head"><span class="ad-kicker">KLIMATKORT</span><h3>Välj ett område</h3></div><p class="ad-note">Klicka på ett område i kartan eller i tabellen. Klimatkortet visar områdets värde i alla fem perspektiv, hur det förhåller sig till övriga DeSO och vad det betyder för fortsatt planering.</p>'; return; }
  const r = v.rows[S.index[st.selected]], val = M.metric(r, k, st.unit), iv = st.unit === 't' ? intervall(r, k) : null;
  let h = '<div class="ad-head"><span class="ad-kicker">KLIMATKORT · ' + esc(r.id) + '</span><h3>' + esc(r.namn) + '</h3></div>' +
    '<div class="ad-hero"><div class="big" style="margin:4px 0">' + sig(val) + '</div><span>' + esc(metricLabel(k)) + '</span><span>' + esc(unitLabel(k, st.unit)) + (statisk(k) ? '' : ' · ' + yearLabel(P.ar)) + '</span>' + (iv ? '<small class="ad-scen">95 %-intervall: ' + sig(iv[0]) + '–' + sig(iv[1]) + '</small>' : '') + '</div>' +
    '<dl class="ad-facts"><div><dt>Invånare ' + (isAck() ? 2050 : P.ar) + '</dt><dd>' + nf(r.bef) + '<small>' + (r.nya_inv > 0.5 ? '+' + nf(r.nya_inv) + ' sedan 2024' : 'oförändrat sedan 2024') + '</small></dd></div><div><dt>Landyta</dt><dd>' + nf(r.land_ha, 1) + ' ha<small>' + nf(r.ohardgjord) + ' % ohårdgjord</small></dd></div>' +
    '<div><dt>Bilar per hushåll</dt><dd>' + nf(r.bil_hh, 2) + '<small>Malmö ' + nf(S.cityCph, 2) + '</small></dd></div><div><dt>Kol i marken</dt><dd>' + nf(r.kol_forrad / 1000, 1) + ' kt CO₂e<small>' + nf(r.kol_ha) + ' t C per ha</small></dd></div></dl>';
  h += '<h4>Fem perspektiv · ' + esc(unitBase(st.unit)) + '</h4>';
  for (const id of M.PERSPEKTIV_ID) {
    const kk = HUVUD[id], alla = v.rows.map(x => M.metric(x, kk, st.unit)), x = M.metric(r, kk, st.unit), sort = alla.filter(a => a != null).sort((a, b) => a - b), plats = sort.filter(a => a < x).length / Math.max(1, sort.length - 1);
    h += '<div class="kp-profil"><span>' + esc(M.PERSPEKTIV[id].namn) + '</span><b>' + sig(x) + '</b><div class="skala"><i style="left:' + (100 * Math.min(1, plats)).toFixed(1) + '%;background:' + PF[id][0] + '"></i></div><small>' + esc(metricLabel(kk)) + ' · högre än ' + nf(100 * plats) + ' % av DeSO</small></div>';
  }
  h += '<h4>Per ny bostad här · t CO₂e 2025–2050</h4><div class="ad-parts">' + [['Bilresor', r.pb.trafik, PF.transport[0]], ['Byggande', r.pb.bygg, PF.ny[0]], ['Mark (förväntad)', r.pb.mark, PF.mark[0]]].map(([n, x, f]) => '<div class="ad-part"><span>' + n + '</span><b>' + nf(x, 1) + '</b><i><span style="display:block;height:100%;width:' + (100 * x / Math.max(1e-9, r.pb.total)).toFixed(1) + '%;background:' + f + '"></span></i></div>').join('') + '<div class="ad-part"><span><b>Summa</b></span><b>' + nf(r.pb.total, 1) + '</b></div></div>';
  const sg = signaler(r, v.rows);
  h += '<h4>Planeringssignaler</h4>' + (sg.length ? sg.map(([b, t]) => '<p class="kp-signal"><b>' + b + '</b>' + esc(t) + '</p>').join('') : '<p class="ad-note">Inga särskilda signaler: området ligger nära medianen i de mått som bevakas.</p>') +
    '<p class="ad-note">Signalerna pekar ut frågor att utreda vidare. De är inga betyg och säger inte rätt eller fel.</p>';
  el.innerHTML = h;
}
function table() {
  const el = $('deso-table'); if (!el) return;
  const v = cur(), f = st.filter.trim().toLowerCase(), kol = [['id', 'DeSO'], ['namn', 'Område'], ['bef', 'Invånare'], ...M.PERSPEKTIV_ID.map(id => [id, M.PERSPEKTIV[id].kort]), ['total', 'Summa'], ...(HUVUD[st.persp] === curMetric() && st.persp !== 'cirk' ? [] : [['v', metricLabel(curMetric())]])];
  if (!kol.some(([c]) => c === st.sort[0])) st.sort = [kol[kol.length - 1][0], -1];
  const val = (r, c) => c === 'id' || c === 'namn' || c === 'bef' ? r[c] : c === 'v' ? M.metric(r, curMetric(), st.unit) : c === 'total' ? M.metric(r, 'total', st.unit) : M.metric({...r, x: M.PERSPEKTIV[c].komp.reduce((s, k) => s + r[k], 0)}, 'x', st.unit);
  const rows = v.rows.filter(r => !f || r.id.toLowerCase().includes(f) || r.namn.toLowerCase().includes(f)).map(r => ({r, c: Object.fromEntries(kol.map(([c]) => [c, val(r, c)]))}));
  const [sc, sd] = st.sort;
  rows.sort((a, b) => { const x = a.c[sc], y = b.c[sc]; return (typeof x === 'string' ? x.localeCompare(y, 'sv') : (x ?? -Infinity) - (y ?? -Infinity)) * sd; });
  el.innerHTML = '<table class="kp-tab"><thead><tr>' + kol.map(([c, n]) => '<th data-sort="' + c + '" class="' + (sc === c ? 'sorted' : '') + '"' + (c === 'namn' ? ' style="text-align:left"' : '') + '>' + esc(n) + (sc === c ? (sd > 0 ? ' ▲' : ' ▼') : '') + '</th>').join('') + '</tr></thead><tbody>' +
    rows.map(({r, c}) => '<tr class="klick' + (r.id === st.selected ? ' vald' : '') + '" data-id="' + r.id + '">' + kol.map(([k]) => '<td' + (k === 'namn' ? ' style="text-align:left"' : '') + '>' + (k === 'id' || k === 'namn' ? esc(c[k]) : k === 'bef' ? nf(c[k]) : sig(c[k])) + '</td>').join('') + '</tr>').join('') + '</tbody></table>';
  el.querySelectorAll('th[data-sort]').forEach(th => th.onclick = () => { const c = th.dataset.sort; st.sort = [c, st.sort[0] === c ? -st.sort[1] : (c === 'id' || c === 'namn' ? 1 : -1)]; table(); });
  el.querySelectorAll('tr[data-id]').forEach(tr => tr.onclick = () => selectArea(tr.dataset.id, true));
}

/* ---------- fält ---------- */
/* [nyckel, etikett, typ, argument, källa]. typ: 'tal' (argument = steg), 'val' (argument = [[värde, text]]), 'reglage' (argument = [min, max, steg, enhet]). */
const andrad = k => String(P[k]) !== String(M.params({elVal: P.elVal})[k]);
function falt([k, label, typ, a, src]) {
  const ch = andrad(k), std = M.params({elVal: P.elVal})[k], dot = ch ? '<span class="changed-dot" title="Ändrat från standard (' + esc(std) + ')"></span>' : '';
  if (typ === 'reglage') return '<div class="kp-reg"><label><span>' + esc(label) + dot + '</span><output id="ut-' + k + '">' + nf(P[k], a[2] < 1 ? 1 : 0) + ' ' + a[3] + '</output></label><input type="range" data-p="' + k + '" data-enhet="' + a[3] + '" min="' + a[0] + '" max="' + a[1] + '" step="' + a[2] + '" value="' + P[k] + '"><span class="src">' + esc(src) + '</span></div>';
  const input = typ === 'val' ? '<select data-p="' + k + '">' + a.map(([v, l]) => '<option value="' + v + '"' + (String(P[k]) === v ? ' selected' : '') + '>' + esc(l) + '</option>').join('') + '</select>' : '<input class="input" type="number" data-p="' + k + '" step="' + a + '" value="' + P[k] + '">';
  return '<div class="field"><label>' + esc(label) + dot + '</label>' + input + '<span class="src">' + esc(src) + (ch ? ' Standard: ' + esc(std) + '.' : '') + '</span></div>';
}
const grupp = (titel, sub, f, cls = 'controls', extra = '') => '<article class="card field-group"><h2>' + titel + '</h2><p class="card-sub">' + sub + '</p><div class="' + cls + '">' + f.map(falt).join('') + '</div>' + extra + '</article>';
const TRAPPOR = [['gransvarde2030', 'Boverkets gränsvärden från 2030, därefter oförändrade'], ['trappa', 'Boverkets färdplan: skärpning vart femte år till 2040'], ['bana', 'Boverkets indikativa bana, linjär 2030–2040'],
  ['insteg', 'SBUF Insteg (dagens takt)'], ['fardplan', 'SBUF Färdplan (snabb omställning)'], ['referens', 'Dagens referensvärden, oförändrade'], ['egen', 'Egen takt (% per år)']];
const F_BEHOV = [
  ['personerPerBostad', 'Personer per ny bostad', 'tal', 0.01, 'Malmö 2024: 365 644 invånare / 172 941 hushåll (SCB via Vägvis).'],
  ['andelFbh', 'Andel flerbostadshus av nya bostäder, %', 'tal', 1, 'Resten är småhus. Antagande; i beståndet 2024 är 84 % av bostäderna i flerbostadshus (SCB).'],
  ['btaFbh', 'BTA per bostad i flerbostadshus, m²', 'tal', 1, 'Antagande, som i Road2Zero-OP.'],
  ['btaSmahus', 'BTA per småhus, m²', 'tal', 1, 'Antagande, som i Road2Zero-OP.'],
  ['arbPerInv', 'Arbetsplatser per ny invånare', 'tal', 0.01, 'Härlett ur ÖP 2023: 37 900 arbetsplatser per 38 850 bostäder × 2,11 personer.'],
  ['btaArb', 'BTA per arbetsplats, m²', 'tal', 1, 'Kontor och service. Antagande, som i Road2Zero-OP.'],
  ['skolBtaPerInv', 'Skola och förskola per ny invånare, m² BTA', 'tal', 0.1, 'Härlett ur ÖP 2023: 16 720 platser per 82 000 invånare × 10 m² per plats.'],
  ['rivTakt', 'Rivning, % av befintlig yta per år', 'tal', 0.01, 'Antagande. Byt mot stadens rivningslov när underlag finns. Rivna byggnader ersätts med nya.']];
const F_BYGG = [
  ['klimatBygg', 'Klimatkrav över tid', 'val', TRAPPOR, 'Boverket (2026b) och SBUF 14381. Före 2030 gäller dagens referensvärde i de tre första valen.'],
  ['refFbh', 'Flerbostadshus i dag, kg CO₂e per m² BTA', 'tal', 1, 'Referensvärde, median A1–A5 (Boverket, 2026b, tabell 2).'],
  ['gvFbh', 'Flerbostadshus, gränsvärde 2030', 'tal', 1, 'Förslag till gränsvärde (Boverket, 2026b, tabell 5).'],
  ['refSmahus', 'Eget småhusvärde i dag (endast eget läge), kg CO₂e/m² BTA', 'tal', 1, 'Egna småhusfaktorer används när eget läge väljs under Stadsutveckling. Automatiskt läge väljer efter Atemp (BOV26).'],
  ['gvSmahus', 'Eget småhusvärde 2030 (endast eget läge)', 'tal', 1, 'Förslag till gränsvärde (Boverket, 2026b, tabell 5).'],
  ['refLokal', 'Lokaler i dag, kg CO₂e per m² BTA', 'tal', 1, 'Referensvärde för kontor; skola 382 (Boverket, 2026b, tabell 2).'],
  ['gvLokal', 'Lokaler, gränsvärde 2030', 'tal', 1, 'Förslag till gränsvärde för kontor, skola och förskola (Boverket, 2026b, tabell 5).'],
  ['traAndel', 'Trästomme i flerbostadshus och lokaler, %', 'tal', 1, 'Andel utöver dagens blandning, som redan ingår i referensvärdet. 0 = dagens blandning.'],
  ['traFaktor', 'Trästomme relativt betongstomme', 'tal', 0.01, '233,6 / 365 kg CO₂e per m² BTA (Malmqvist m.fl., 2023; SBUF 14381).'],
  ['efRivning', 'Rivning, kg CO₂e per m² BTA', 'tal', 1, 'Pilotprojekt 1–26, de flesta 4–9 (IVL, 2022).'],
  ['grundKgBta', 'Grundläggning, kg CO₂e per m² BTA som nybyggs', 'tal', 1, 'Pålning, branschschablon som i Road2Zero-Plan. Sätt 0 där pålning inte behövs. Påbyggnad och omvandling har ingen grundläggning.'],
  ['anlKgMark', 'Gator, ledningar och allmän plats, kg CO₂e per m² utvecklad mark', 'tal', 1, 'Antagande. Gäller utbyggnadsområden; förtätning antas använda befintlig infrastruktur. Uppmätta projekt varierar mycket (SBUF 14381).']];
const F_LOK = [
  ['lokUtb', 'Andel av nybyggnaden i ÖP:s utbyggnadsområden, %', 'tal', 1, 'Resten är förtätning i befintlig stad. Antagande. Kapaciteten är 38 850 bostäder; blir områdena fulla går resten till förtätning.'],
  ['omrOrdning', 'Ordning mellan utbyggnadsområdena', 'val', [['proportionell', 'Alla områden byggs i samma takt'], ['fokus', 'Fokus 1 först, sedan Fokus 2'], ['klimat', 'Lägst klimatpåverkan per bostad först']], 'Klimatordningen rangordnar områdena efter bilresor och kolförlust per bostad.'],
  ['fortFordelning', 'Förtätningens fördelning', 'val', [['jamn', 'Efter folkmängd (jämnt)'], ['bilsnal', 'Lägen med lågt bilinnehav prioriteras']], 'Bilsnåla lägen: vikten är folkmängd delad med bilar per hushåll i kvadrat (modellval).'],
  ['fortMarkAndel', 'Förtätning på ohårdgjord mark, %', 'tal', 1, 'Andel av förtätningens markanspråk som tar parker, gårdar och annan ohårdgjord mark. Standard 0: redan hårdgjord mark.']];
const F_CIRK1 = [
  ['suffBefintligt', 'Nya invånare som ryms i befintligt bestånd', 'reglage', [0, 50, 1, '%'], 'Högre nyttjande: lägre vakans, delat boende, flyttkedjor. Dessa invånare kräver ingen ny yta.'],
  ['suffBoyta', 'Mindre yta per ny bostad', 'reglage', [0, 40, 1, '%'], 'Yteffektiva planlösningar och delade ytor.'],
  ['suffLokal', 'Mindre lokalyta per ny invånare', 'reglage', [0, 60, 1, '%'], 'Samnyttjande, högre nyttjandegrad och tomma lokaler som tas i bruk.']];
const F_CIRK2 = [
  ['omvAndel', 'Bostadsbehov som möts genom omvandling av lokaler', 'reglage', [0, 60, 1, '%'], 'Kontor och andra lokaler byggs om till bostäder. Fördelas på DeSO efter befintlig lokalyta.'],
  ['pabAndel', 'Bostadsbehov som möts genom påbyggnad', 'reglage', [0, 40, 1, '%'], 'Nya våningar på befintliga flerbostadshus. Fördelas efter befintlig yta i flerbostadshus.'],
  ['renoveraAndel', 'Rivningar som ersätts av renovering', 'reglage', [0, 100, 5, '%'], 'Byggnaden renoveras i stället för att rivas och ersättas med en ny.'],
  ['aterbrukAndel', 'Återbrukat material i nybyggnad och påbyggnad', 'reglage', [0, 60, 1, '%'], 'Andel av materialens klimatpåverkan som ersätts av återbrukade produkter.']];
const F_CIRK3 = [
  ['efOmv', 'Omvandling, kg CO₂e per m² BTA', 'tal', 1, 'Scenarioantagande. Numeriskt stöd för intervallet 40–160 har inte verifierats, se IVL22 i Källkontroll.'],
  ['omvTak', 'Tak för omvandling, % av befintlig lokalyta', 'tal', 1, 'Antagande. Över taket nybyggs resten.'],
  ['pabFaktor', 'Påbyggnad relativt nybyggnad', 'tal', 0.05, 'Antagande: grundläggning och källare utgår.'],
  ['pabTak', 'Tak för påbyggnad, % av flerbostadshusens yta', 'tal', 1, 'Antagande. Över taket nybyggs resten.'],
  ['efRenovering', 'Renovering, kg CO₂e per m² BTA', 'tal', 1, 'Scenarioantagande, inte verifierat generellt renoveringsvärde. Se IVL22 i Källkontroll.'],
  ['aterbrukBesparing', 'Återbrukets besparing, %', 'tal', 1, 'Antagande: återbrukat material har så mycket lägre klimatpåverkan än nytt.']];
const F_TRANSPORT = [
  ['flottaVal', 'Fordonsflottans utveckling', 'val', [['nv2026', 'Ärvt flottcenario – exakta takter ej verifierade'], ['oforandrad', 'Oförändrad flotta'], ['egen', 'Egen bana']], 'Bränslekedjans klimatpåverkan per fordonskilometer. Samma val som i Road2Zero-OP.'],
  ['flotta2030', 'Egen bana: flottan 2030 relativt 2024', 'tal', 0.05, 'Används bara med valet Egen bana. 1 = oförändrat.'],
  ['flotta2040', 'Egen bana: flottan 2040', 'tal', 0.05, 'Linjärt mellan åren.'],
  ['flotta2050', 'Egen bana: flottan 2050', 'tal', 0.05, 'Linjärt mellan åren.'],
  ['trafikForandring2050', 'Trafikarbete i befintlig stad 2050, % mot 2024', 'tal', 1, 'Linjär förändring. Standard 0: bara flottan och nya invånare förändrar utsläppen.'],
  ['bilFaktorUtb', 'Bilar per nytt hushåll i utbyggnadsområden', 'tal', 0.05, 'Relativt värdområdets bilinnehav 2024. Under 1 = kollektivtrafik och mobilitetsåtgärder på plats från start.'],
  ['bilFaktorBef', 'Bilar per nytt hushåll i befintlig stad', 'tal', 0.05, 'Förtätning, omvandling och påbyggnad. Relativt värdområdets bilinnehav 2024.'],
  ['andelKmInomMalmo', 'Nya bilars körsträcka inom Malmö (perspektiv A)', 'tal', 0.05, 'Antagande, som i Road2Zero-OP.']];
const F_ENERGI = [
  ['elVal', 'Elens klimatfaktor', 'val', [['boverket', 'Boverket 37 g CO₂e/kWh'], ['iea', 'IEA handelskorrigerad 26 g CO₂e/kWh'], ['egen', 'Eget startvärde']], 'Samma tre val och utvecklingstakter som i Road2Zero-OP.'],
  ['efElEgen', 'Eget startvärde för el, kg CO₂e/kWh', 'tal', 0.001, 'Används bara med valet Eget startvärde.'],
  ['efFv', 'Fjärrvärme, kg CO₂e/kWh', 'tal', 0.001, 'Svenskt medelvärde (Boverket, 2026a). Takt enligt EU:s referensscenario 2020.'],
  ['beccs', 'Koldioxidavskiljning vid Sysav', 'val', [['nej', 'Nej'], ['ja', 'Ja']], 'Sänker fjärrvärmens klimatfaktor från valt år. Av som standard.'],
  ['beccsAr', 'Avskiljning i drift från år', 'tal', 1, 'Sysavs plan: 2030.'],
  ['beccsMinskning', 'Avskiljningens effekt på fjärrvärmen, %', 'tal', 1, 'Härlett i Road2Zero-OP: 65 % av värmen × 400/600 kt avskilt.'],
  ['effektivisering2050', 'Energieffektivisering i befintligt bestånd till 2050, %', 'tal', 1, 'Lägre levererad energi, linjärt från 2024. Standard 0.'],
  ['energiNy', 'Nya byggnader, kWh per m² Atemp och år', 'tal', 1, 'Median för nya byggnader i klass A–B i Malmös energideklarationer (Road2Zero-OP).'],
  ['elandelNy', 'Nya byggnader, elandel', 'tal', 0.01, 'Median i samma urval. Resten är fjärrvärme.'],
  ['atempNy', 'Atemp per BTA', 'tal', 0.01, 'Antagande.']];
const F_MARK = [
  ['kolKvar', 'Kol kvar under bebyggd mark, t C/ha', 'tal', 1, 'Länsstyrelsen i Uppsala län (2025), som i kolkartan.'],
  ['tathetFbh', 'Bostäder per ha, tät blandad stad', 'tal', 1, 'Mätt i Västra hamnen och Hyllievång syd (kolkartan).'],
  ['ohardSlutFbh', 'Ohårdgjord andel i slutläget, tät blandad stad', 'tal', 0.01, 'Mätt i samma DeSO ur SLU-lagret (spann 0,04–0,32).'],
  ['tathetSmahus', 'Bostäder per ha, småhus', 'tal', 1, 'Mätt i Bunkeflostrand öst och väst (kolkartan).'],
  ['ohardSlutSmahus', 'Ohårdgjord andel i slutläget, småhus', 'tal', 0.01, 'Mätt i samma DeSO. Trädgårdar räknas som gräsmark.'],
  ['arbEkv', 'En arbetsplats i bostadsekvivalenter', 'tal', 0.01, 'Modellval: 25 / 90 m² BTA.'],
  ['verksHela', 'Verksamhetsområden tar hela den ohårdgjorda ytan', 'val', [['ja', 'Ja'], ['nej', 'Nej, efter täthet']], 'Som i kolkartan.']];

/* ---------- 03 Befolkning & nybyggnation ---------- */
function popView() {
  const pr = M.perioder(R), niva = Object.entries(M.POP_NIVA).find(([, o]) => M.MIL.every(m => o[m] === P['pop' + m]));
  let h = kontext() + '<article class="card"><h2>Folkmängd i Malmö</h2><p class="card-sub">Ange folkmängden vid utgången av varje år. Mellan åren räknar modellen linjärt. 2024: ' + nf(S.bef0) + ' invånare (SCB).</p>' +
    '<div class="kp-val">' + [['prognos', 'Malmö stads prognos med framskrivning'], ['lag', 'Låg: halva ökningen'], ['hog', 'Hög: 50 % större ökning']].map(([k, n]) => '<button class="secondary small-btn' + (niva && niva[0] === k ? ' on' : '') + '" data-popniva="' + k + '">' + n + '</button>').join('') + '</div>' +
    '<div class="kp-pop">' + M.MIL.map((m, i) => '<label>' + m + '<input class="input" type="number" step="100" data-p="pop' + m + '" value="' + P['pop' + m] + '"><small>' + (pr[i].N >= 0 ? '+' : '') + nf(pr[i].N) + ' sedan ' + (i ? M.MIL[i - 1] : 2024) + (andrad('pop' + m) ? ' · standard ' + nf(M.POP_STD[m]) : '') + '</small></label>').join('') + '</div>' +
    '<p class="small">Standard: Malmö stads befolkningsprognos 2025–2035 ger 371 626 invånare 2026 och 395 094 år 2035; 2030 är 381 846 enligt tabell 1 i samma prognos (MALMO25). Åren 2040–2050 är en framskrivning med prognosens sista årsökning, 2 660 invånare per år. Framskrivningen är ett modellval, ingen prognos.</p></article>';
  h += '<article class="card"><h2>Behovet av yta och hur det möts</h2><p class="card-sub">Summor per period. Nya invånare × yta per invånare ger behovet; cirkulära åtgärder minskar det som måste nybyggas.</p>' + behovTabell(false) + '</article>';
  h += window.KPCircular.area(P);
  h += grupp('Behov av bostäder och lokaler', 'Hur folkökningen översätts till bruttoarea (BTA).', F_BEHOV.filter(f=>f[0]!=='personerPerBostad'));
  const fak = M.AR.slice(1).map(y => R.stad.find(s => s.year === y));
  h += grupp('Typ av bebyggelse och klimatpåverkan per m² BTA', 'Byggskedet, modul A1–A5. Gäller nya byggnader och byggnader som ersätter rivna.', F_BYGG, 'controls',
    '<h3 style="font-size:13px;margin:20px 0 6px">Klimatfaktorer som används, kg CO₂e per m² BTA</h3><div class="table-wrap calc-full"><table class="kp-tab"><thead><tr><th>Byggnadstyp</th><th>2025</th>' + fak.map(s => '<th>' + s.year + '</th>').join('') + '</tr></thead><tbody>' +
    [['Flerbostadshus', 'fF'], ['Småhus', 'fS'], ['Lokaler', 'fL']].map(([n, k]) => '<tr><td>' + n + '</td><td>' + nf(R.stad[1][k]) + '</td>' + fak.map(s => '<td>' + nf(s[k]) + '</td>').join('') + '</tr>').join('') + '</tbody></table></div><p class="small">Värdena inkluderar valet av trästomme och återbruk. Egen takt anges per period under Antaganden.</p>');
  h += grupp('Var byggs det?', 'Lokaliseringen styr bilresor och markanspråk. Omvandling och påbyggnad hamnar där byggnaderna redan finns.', F_LOK, 'controls');
  const om = R.areas.slice().sort((a, b) => b.mark - a.mark);
  h += '<article class="card"><h2>Utbyggnadsområden i ÖP 2023</h2><p class="card-sub">Hur mycket av varje område som byggs till 2050 i scenariot, och vad det betyder för marken. Sorterat efter kolförlust.</p><div class="table-wrap"><table class="kp-tab"><thead><tr><th>Område</th><th>Fokus</th><th>Kapacitet,<br>bostäder</th><th>Byggt<br>2050</th><th>Andel<br>byggt</th><th>Ohårdgjord<br>mark, ha</th><th>Tas vid full<br>utbyggnad, ha</th><th>Kol,<br>t C/ha</th><th>Mark 2025–2050,<br>kt CO₂e</th><th>Bilresor per<br>bostad, t CO₂e</th></tr></thead><tbody>' +
    om.map(a => '<tr><td>' + esc(a.namn) + (a.kategori === 'Verksamhetsområde' ? ' <small>(verksamheter)</small>' : '') + '</td><td>' + a.fokus + '</td><td>' + nf(a.bostader) + '</td><td>' + nf(a.dw) + '</td><td>' + nf(100 * a.f) + ' %</td><td>' + nf(a.Au, 1) + '</td><td>' + nf(a.tagen, 1) + '</td><td>' + nf(a.Cu) + '</td><td>' + nf(a.mark / 1000, 2) + '</td><td>' + nf(a.trafik, 1) + '</td></tr>').join('') +
    '<tr class="sum"><td>Summa</td><td></td><td>' + nf(om.reduce((s, a) => s + a.bostader, 0)) + '</td><td>' + nf(om.reduce((s, a) => s + a.dw, 0)) + '</td><td></td><td>' + nf(om.reduce((s, a) => s + a.Au, 0), 1) + '</td><td>' + nf(om.reduce((s, a) => s + a.tagen, 0), 1) + '</td><td></td><td>' + nf(om.reduce((s, a) => s + a.mark, 0) / 1000, 1) + '</td><td></td></tr></tbody></table></div>' +
    (pr.some(p => p.fullt > 0.5) ? '<p class="kp-varning">Utbyggnadsområdena blir fulla: ' + nf(pr.reduce((s, p) => s + p.fullt, 0)) + ' bostäder har flyttats till förtätning.</p>' : '') + '</article>';
  return h + aterstall();
}
const aterstall = () => '<article class="card"><div class="button-row"><button class="primary" data-reset="1">Återställ alla standardvärden</button><button class="secondary" data-view="overview">Se resultatet →</button><button class="secondary" data-view="map">Öppna kartan →</button></div><p class="small">Antagandena sparas i den här webbläsaren. Exportera JSON för att dela dem.</p></article>';

/* ---------- 04 Cirkularitet ---------- */
function cirkView() {
  const pr = M.perioder(R), ref = M.perioder(Rref), niva = Object.entries(M.CIRK_NIVA).find(([, o]) => M.CIRK.every(k => o[k] === P[k]));
  const sum = (a, k) => a.reduce((s, p) => s + p[k], 0), bRef = sum(ref, 'byggande') + sum(ref, 'mark'), bSc = sum(pr, 'byggande') + sum(pr, 'mark');
  let h = kontext() + window.KPCircular.all(P,S,R,Rref) + notice('<strong>Stegmodell.</strong> Samma befolkningsbana jämförs; yta per person och hushåll kan vara en åtgärd. Först minskas behovet, sedan används det som finns (omvandling, påbyggnad, renovering), och det som ändå nybyggs görs med återbrukat material. Allt jämförs med referensen där hela behovet nybyggs.', 'info');
  h += '<section class="kpis four"><article class="card kpi-main"><div class="kpi-label">Byggande och mark 2025–2050</div><div class="kpi-value">' + kt(bSc) + ' <span class="unit">kt CO₂e</span></div><div class="kpi-foot">Referens: ' + kt(bRef) + ' kt' + (bRef > 0 && M.harCirk(P) ? ' · <span class="delta-down">' + nf(100 * (bSc - bRef) / bRef, 1) + ' %</span>' : '') + '</div></article>' +
    '<article class="card"><div class="kpi-label">Undvikna utsläpp</div><div class="kpi-value">' + kt(bRef - bSc) + ' <span class="unit">kt CO₂e</span></div><div class="kpi-foot">2025–2050, byggande och förändrad markanvändning</div></article>' +
    '<article class="card"><div class="kpi-label">Per m² behövd yta</div><div class="kpi-value">' + nf(sum(pr, 'byggande') * 1000 / Math.max(1, sum(pr, 'behov'))) + ' <span class="unit">kg CO₂e</span></div><div class="kpi-foot">Referens: ' + nf(sum(ref, 'byggande') * 1000 / Math.max(1, sum(ref, 'behov'))) + ' kg per m² BTA</div></article>' +
    '<article class="card"><div class="kpi-label">Nybyggd yta</div><div class="kpi-value">' + nf(sum(pr, 'nybyggd') / 1e6, 2) + ' <span class="unit">Mm² BTA</span></div><div class="kpi-foot">av ' + nf(sum(pr, 'behov') / 1e6, 2) + ' Mm² behov · referens ' + nf(sum(ref, 'nybyggd') / 1e6, 2) + '</div></article></section>';
  h += '<article class="card"><h2>Välj åtgärder</h2><p class="card-sub">Tre färdiga nivåer som räkneexempel, eller egna värden med reglagen.</p><div class="kp-val">' + [['referens', 'Referens: allt nybyggs'], ['mattlig', 'Måttlig stegmodell'], ['ambitios', 'Ambitiös stegmodell']].map(([k, n]) => '<button class="secondary small-btn' + (niva && niva[0] === k ? ' on' : '') + '" data-cirkniva="' + k + '">' + n + '</button>').join('') + '</div>' +
    '<h3 style="font-size:13px;margin:8px 0 10px;display:flex;align-items:center"><span class="kp-steg">1</span>Minska behovet (sufficiency)</h3><div class="kp-reglage">' + F_CIRK1.filter(f=>P.ytaVal==='typologi'||f[0]!=='suffBoyta').map(falt).join('') + '</div>' +
    '<h3 style="font-size:13px;margin:22px 0 10px;display:flex;align-items:center"><span class="kp-steg">2</span>Använd det som finns, och återbruka i det som byggs</h3><div class="kp-reglage">' + F_CIRK2.map(falt).join('') + '</div>' +
    (R.stad.some(s => s.takOmv) ? '<p class="kp-varning">Taket för omvandling är nått: ' + nf(R.tak.cumOmv / 1000) + ' 000 m² av befintlig lokalyta har omvandlats. Resten av behovet nybyggs.</p>' : '') +
    (R.stad.some(s => s.takPab) ? '<p class="kp-varning">Taket för påbyggnad är nått: ' + nf(R.tak.cumPab / 1000) + ' 000 m² har byggts på. Resten av behovet nybyggs.</p>' : '') + '</article>';
  const ytor = [['nybyggd', 'Nybyggs', '#c9982b'], ['pab', 'Påbyggnad', '#7fc4b5'], ['omv', 'Omvandling', '#2f9c8a'], ['ren', 'Renovering', '#125a4e'], ['suffBta', 'Minskat behov', '#c9d6cf']];
  const utsl = [['bygg', 'Nybyggnad och rivning', KF.bygg], ['anl', 'Anläggning', KF.anl], ['omb', 'Omvandling, påbyggnad, renovering', KF.omb], ['mark', 'Markanvändning', KF.mark],['byggdel','Separata byggdelar',KF.byggdel]];
  h += '<section class="grid2 grid-even"><article class="card"><h2>Hur behovet av yta möts</h2><p class="card-sub">1 000 m² BTA per period fram till angivet år.</p>' +
    staplar(pr.map(p => ({etikett: String(p.till), staplar: [{v: p}]})), ytor, {div: 1000, enhet: '1 000 m² BTA', aria: 'Behov av yta per period och hur det möts'}) + '</article>' +
    '<article class="card"><h2>Klimatpåverkan av den yta som behövs</h2><p class="card-sub">kt CO₂e per period. Vänster stapel (blek): referens. Höger: valda åtgärder.</p>' +
    staplar(pr.map((p, i) => ({etikett: String(p.till), staplar: [{namn: 'ref.', v: ref[i], matt: true}, {namn: 'vald', v: p}]})), utsl, {div: 1000, dec: 0, enhet: 'kt CO₂e', aria: 'Klimatpåverkan per period, referens och valda åtgärder'}) + '</article></section>';
  h += '<article class="card"><h2>Behov, åtgärder och klimatpåverkan per period</h2><p class="card-sub">Fram till 2030, 2035, 2040, 2045 och 2050.</p>' + behovTabell(false) + '</article>';
  h += grupp('Klimatfaktorer och tak', 'Värden för omvandling, påbyggnad, renovering och återbruk.', F_CIRK3);
  return h + aterstall();
}

/* ---------- 05 Antaganden ---------- */
function paramsView() {
  const ar = [2024, 2026, ...M.MIL].map(y => R.stad.find(s => s.year === y)), takt = (n, pre) => '<tr><td>' + n + '</td>' + [1, 2, 3, 4, 5].map(k => '<td><input class="input-small" type="number" step="0.1" data-p="' + pre + k + '" value="' + P[pre + k] + '" aria-label="' + esc(n) + ' ' + M.TAKTPERIOD[k - 1].join('–') + '"' + (andrad(pre + k) ? ' style="border-color:#daa84d"' : '') + '></td>').join('') + '</tr>';
  let h = kontext() + '<article class="card"><h2>Emissionsfaktorer över tid</h2><p class="card-sub">Startvärdet gäller till och med 2026. Från 2027 förändras faktorn med en årlig takt per period. Samma upplägg och standardvärden som i Road2Zero-OP.</p>' +
    '<div class="table-wrap calc-full"><table class="kp-tab"><thead><tr><th>Faktor</th>' + ar.map(s => '<th>' + s.year + '</th>').join('') + '</tr></thead><tbody>' +
    '<tr><td>El, g CO₂e/kWh</td>' + ar.map(s => '<td>' + nf(s.efEl * 1000, 1) + '</td>').join('') + '</tr><tr><td>Fjärrvärme, g CO₂e/kWh</td>' + ar.map(s => '<td>' + nf(s.efFv * 1000, 1) + '</td>').join('') + '</tr>' +
    '<tr><td>Fordonsflottans bränslekedja, index</td>' + ar.map(s => '<td>' + nf(s.flotta, 2) + '</td>').join('') + '</tr><tr><td>Nybyggnad flerbostadshus, kg CO₂e/m² BTA</td>' + ar.map(s => '<td>' + nf(s.fF) + '</td>').join('') + '</tr></tbody></table></div>' +
    '<h3 style="font-size:13px;margin:20px 0 6px">Årlig förändring, % per år</h3><div class="table-wrap calc-full"><table class="kp-tab"><thead><tr><th>Faktor</th>' + M.TAKTPERIOD.map(p => '<th>' + p.join('–') + '</th>').join('') + '</tr></thead><tbody>' + takt('El', 'elR') + takt('Fjärrvärme', 'fvR') + takt('Nybyggnad, egen takt', 'byggR') + '</tbody></table></div>' +
    '<p class="small">Raden Nybyggnad, egen takt används bara med valet Egen takt under Befolkning & nybyggnation.</p></article>';
  h += grupp('Transport & mobilitet', 'Nuläget kommer från Vägvis 2.3.1. Här väljs hur flottan och trafiken utvecklas och hur nya hushåll reser.', F_TRANSPORT);
  h += grupp('Energi', 'Nuläget kommer från energideklarationer och skattade byggnader (Road2Zero-OP). Här väljs emissionsfaktorer och nya byggnaders energi.', F_ENERGI);
  h += grupp('Markens klimatvärde', 'Kolförråden kommer från SLU:s kolkartor. Här väljs hur tätt det byggs och hur mycket mark som förblir ohårdgjord.', F_MARK);
  return h + aterstall();
}

/* ---------- 06 Metod & källor ---------- */
/* ---------- export ---------- */
function download(name, text, mime) { const b = new Blob([text], {type: mime}), a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 1000); }
const csvTal = x => x == null || !Number.isFinite(x) ? '' : String(Math.round(x * 1000) / 1000).replace('.', ',');
function csvDeso() {
  const v = cur(), kol = ['mark', 'bygg', 'anl', 'omb', 'mob', 'nymob', 'energi', 'nydrift', 'total', 'undvikt','cirk_bidrag','undviket_bygg','undviket_total', 'byggdel', 'bef', 'nya_inv', 'bta_ny', 'land_ha', 'kol_forrad', 'kol_ha', 'ohardgjord', 'kol_risk', 'bil_hh', 'kwh_m2', 'pot_omv', 'pot_pab', 'per_bostad'];
  return '﻿' + ['deso', 'omrade', 'ar', 'mobilitet', ...kol].join(';') + '\n' + v.rows.map(r => [r.id, r.namn, yearLabel(P.ar), P.perspektiv, ...kol.map(k => csvTal(r[k]))].join(';')).join('\n');
}
const csvAr = () => '﻿' + ['ar', 'folkmangd', ...M.KOMP, 'total'].join(';') + '\n' + M.stadPerAr(R).map((r, i) => [r.year, csvTal(R.stad[i].pop), ...M.KOMP.map(k => csvTal(r[k])), csvTal(r.total)].join(';')).join('\n');
function csvPerioder() {
  const k = ['pop', 'N', 'bost', 'behov', 'brutto', 'riv', 'suffBta', 'omv', 'pab', 'ren', 'nybyggd', 'utvHa', 'bygg', 'byggdel', 'anl', 'omb', 'byggande', 'mark'], ref = M.perioder(Rref);
  return '﻿' + ['fran', 'till', ...k, 'byggande_referens'].join(';') + '\n' + M.perioder(R).map((p, i) => [p.fran, p.till, ...k.map(x => csvTal(p[x])), csvTal(ref[i].byggande)].join(';')).join('\n');
}
const jsonAllt = () => JSON.stringify({modell: 'Klimatperspektiv', version: M.VERSION, kallkontroll: window.KPDevelopment.audit, skapad: new Date().toISOString(), antaganden: P, stad_per_ar: M.stadPerAr(R), perioder: M.perioder(R), utbyggnadsomraden: R.areas}, null, 1);

/* ---------- rendering och händelser ---------- */
function render() {
  if (map && st.view !== 'map') { map.remove(); map = null; }
  $('view').innerHTML = (['method','sources'].includes(st.view)?'':notice('Version 1.2: scenarier för framtida energi, trafik och flera schabloner har kvarstående verifieringsbehov. Se <button data-view="sources">Källkontroll</button>.')) + {overview, map: mapView, pop: popView, cirk: cirkView, parameters: paramsView, development: () => window.KPDevelopment.render(P,S), sources: () => window.KPDevelopment.sources(), method: () => window.KPDevelopment.details()}[st.view]();
  if (st.view === 'map') { drawMap(); detail(); table();
    $('metric').onchange = e => { st.metric[st.persp] = e.target.value; render(); };
    $('unit').onchange = e => { st.unit = e.target.value; render(); };
    $('table-filter').oninput = e => { st.filter = e.target.value; table(); }; }
}
function go(v) { st.view = v; renderChrome(); render(); window.scrollTo({top: 0}); }
function resetP() { P = M.params({ar: P.ar, perspektiv: P.perspektiv}); rakna(); store.set(P); renderChrome(); render(); }
document.addEventListener('click', e => {
  const pb = e.target.closest('[data-persp]');
  if (pb) {   // byt perspektiv: små kartor öppnar kartan, och från en indatasida visas översikten
    st.persp = pb.dataset.persp;
    if (pb.dataset.oppna) st.view = 'map'; else if (!['overview', 'map'].includes(st.view)) st.view = 'overview';
    renderChrome(); render(); if (pb.dataset.oppna) window.scrollTo({top: 0}); return;
  }
  const nav = e.target.closest('[data-view]'); if (nav) { e.preventDefault(); go(nav.dataset.view); return; }
  const y = e.target.closest('[data-year]'); if (y) { setP({ar: y.dataset.year === 'ack' ? 'ack' : Number(y.dataset.year)}); return; }
  const m = e.target.closest('.model-switch button[data-model]'); if (m) { setP({perspektiv: m.dataset.model}); return; }
  const pn = e.target.closest('[data-popniva]'); if (pn) { setP(Object.fromEntries(M.MIL.map(a => ['pop' + a, M.POP_NIVA[pn.dataset.popniva][a]]))); return; }
  const cn = e.target.closest('[data-cirkniva]'); if (cn) { setP(M.CIRK_NIVA[cn.dataset.cirkniva]); return; }
  if (e.target.closest('[data-reset]')) resetP();
});
document.addEventListener('input', e => { const el = e.target; if (el.type === 'range' && el.dataset.p) { const o = $('ut-' + el.dataset.p); if (o) o.textContent = nf(Number(el.value), Number(el.step) < 1 ? 1 : 0) + ' ' + el.dataset.enhet; } });
document.addEventListener('change', e => {
  const el = e.target; if (!el.dataset || !el.dataset.p) return;
  const k = el.dataset.p, v = el.value;
  if (k === 'elVal' && M.EL_ALT[v]) { setP({elVal: v, ...Object.fromEntries(M.EL_ALT[v].takt.map((r, i) => ['elR' + (i + 1), r]))}); return; }   // nytt elval: valets standardtakt
  try { setP({[k]: v}); } catch(err) { $('message').innerHTML=notice(esc(err.message)); renderChrome(); render(); }
});
$('export').onclick = () => $('export-dialog').showModal();
$('close-export').onclick = () => $('export-dialog').close();
$('print').onclick = () => { $('export-dialog').close(); window.print(); };
$('download-csv').onclick = () => download('klimatperspektiv_deso_' + yearLabel(P.ar) + '.csv', csvDeso(), 'text/csv;charset=utf-8');
$('download-years').onclick = () => download('klimatperspektiv_malmo_per_ar.csv', csvAr(), 'text/csv;charset=utf-8');
$('download-periods').onclick = () => download('klimatperspektiv_behov_per_period.csv', csvPerioder(), 'text/csv;charset=utf-8');
$('download-json').onclick = () => download('klimatperspektiv_antaganden_resultat.json', jsonAllt(), 'application/json');
$('upload-json').onchange = e => { const f = e.target.files[0]; if (!f) return; f.text().then(t => { try { const o = JSON.parse(t), a = o.antaganden || o; if (!a || typeof a !== 'object') throw new Error(); const next = M.params(a); M.compute(S,next); P = next; rakna(); store.set(P); $('export-dialog').close(); renderChrome(); render(); $('message').innerHTML = notice('Antagandena i ' + esc(f.name) + ' är inlästa.', 'info'); }
  catch (err) { $('message').innerHTML = notice('Filen kunde inte läsas. Välj en JSON-fil som exporterats från Klimatperspektiv.'); } }); e.target.value = ''; };
$('reset-side').onclick = resetP;
renderChrome(); render();
window.KlimatperspektivApp = {get params() { return P; }, get result() { return R; }, get reference() { return Rref; }, S, D, go, setP, cur, st};
})();
